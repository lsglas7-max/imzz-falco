package com.imzyyknox.gameturbo;

import android.content.Context;
import android.os.StatFs;
import android.os.storage.StorageManager;
import java.io.File;
import java.io.FileOutputStream;

/**
 * Bersihkan cache SEMUA aplikasi sekaligus tanpa membuka aplikasi satu per satu.
 * Memakai API resmi StorageManager.allocateBytes: saat aplikasi meminta ruang lebih besar dari yang kosong,
 * Android sendiri menghapus cache aplikasi lain untuk memenuhinya. Berkas sementara langsung dihapus lagi.
 * Hasil bisa lebih kecil dari pembersihan manual: sistem yang memutuskan cache mana yang dilepas.
 */
final class CacheEngine {
    static final class Result { long freed; boolean ok; String msg; }

    static Result reclaim(Context c) {
        Result r = new Result();
        File f = new File(c.getFilesDir(), "imzyy_reclaim.tmp");
        try {
            StorageManager sm = (StorageManager) c.getSystemService(Context.STORAGE_SERVICE);
            long freeBefore = new StatFs(c.getFilesDir().getPath()).getAvailableBytes();
            long alloc = sm.getAllocatableBytes(StorageManager.UUID_DEFAULT);
            long want = alloc - 16L * 1024 * 1024;
            if (want <= freeBefore) { r.ok = true; r.msg = "Tidak ada cache yang bisa dilepas sistem"; return r; }
            try (FileOutputStream o = new FileOutputStream(f)) {
                sm.allocateBytes(o.getFD(), want);
            }
            f.delete();
            long freeAfter = new StatFs(c.getFilesDir().getPath()).getAvailableBytes();
            r.freed = Math.max(0, freeAfter - freeBefore);
            r.ok = true; r.msg = "Cache dilepas sistem";
        } catch (Throwable e) {
            r.ok = false; r.msg = "Sistem menolak: " + e.getClass().getSimpleName();
        } finally {
            if (f.exists()) f.delete();
        }
        return r;
    }
}
