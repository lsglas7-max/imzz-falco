package com.imzyyknox.gameturbo;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import java.io.ByteArrayOutputStream;
import java.util.concurrent.atomic.AtomicBoolean;

/** Mesin voice changer offline (rekam + efek pitch/robot). Dipakai langsung dari floating window. */
final class VoiceEngine {
    static final int RATE = 22050;
    private final AtomicBoolean recording = new AtomicBoolean(false);
    private final ByteArrayOutputStream pcm = new ByteArrayOutputStream();
    private AudioRecord recorder;
    private AudioTrack track;

    boolean isRecording() { return recording.get(); }
    boolean hasAudio() { synchronized (pcm) { return pcm.size() >= 2048; } }
    int seconds() { synchronized (pcm) { return pcm.size() / 2 / RATE; } }

    /** Mengembalikan null kalau berhasil, atau pesan error. */
    String start() {
        if (recording.get()) return null;
        try {
            int min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            recorder = new AudioRecord(MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min, RATE));
            if (recorder.getState() != AudioRecord.STATE_INITIALIZED) { recorder.release(); recorder = null; return "Mikrofon tidak tersedia"; }
            synchronized (pcm) { pcm.reset(); }
            recording.set(true);
            final AudioRecord r = recorder;
            r.startRecording();
            new Thread(() -> {
                short[] buf = new short[2048];
                while (recording.get()) {
                    int n = r.read(buf, 0, buf.length);
                    if (n > 0) synchronized (pcm) { for (int i = 0; i < n; i++) { pcm.write(buf[i] & 255); pcm.write((buf[i] >> 8) & 255); } }
                }
            }).start();
            return null;
        } catch (Exception e) { recording.set(false); return "Gagal membuka mikrofon: " + e.getMessage(); }
    }

    void stop() {
        recording.set(false);
        try { if (recorder != null) { recorder.stop(); recorder.release(); } } catch (Exception ignored) { }
        recorder = null;
    }

    void stopPlay() {
        try { if (track != null) { track.pause(); track.flush(); track.release(); } } catch (Exception ignored) { }
        track = null;
    }

    /** Mengembalikan null kalau berhasil, atau pesan error. */
    String play(float pitch, boolean robot) {
        if (recording.get()) stop();
        byte[] raw; synchronized (pcm) { raw = pcm.toByteArray(); }
        if (raw.length < 2048) return "Rekam suara dulu";
        try {
            int count = raw.length / 2; short[] in = new short[count];
            for (int i = 0; i < count; i++) in[i] = (short) ((raw[i * 2] & 255) | (raw[i * 2 + 1] << 8));
            int outCount = Math.max(1, (int) (count / pitch)); short[] out = new short[outCount];
            for (int i = 0; i < outCount; i++) {
                float src = i * pitch; int a = Math.min(count - 1, (int) src), z = Math.min(count - 1, a + 1); float frac = src - a;
                float sample = in[a] * (1 - frac) + in[z] * frac;
                if (robot) sample *= 0.25f + 0.75f * Math.sin(2 * Math.PI * 42 * i / RATE);
                out[i] = (short) Math.max(Short.MIN_VALUE, Math.min(Short.MAX_VALUE, sample));
            }
            stopPlay();
            track = new AudioTrack(AudioManager.STREAM_MUSIC, RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT, out.length * 2, AudioTrack.MODE_STATIC);
            track.write(out, 0, out.length); track.play();
            return null;
        } catch (Exception e) { return "Playback gagal: " + e.getMessage(); }
    }

    void release() { stop(); stopPlay(); }
}
