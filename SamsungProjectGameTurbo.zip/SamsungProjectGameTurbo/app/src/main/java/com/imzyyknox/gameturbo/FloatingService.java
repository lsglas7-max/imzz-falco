package com.imzyyknox.gameturbo;

import android.animation.ValueAnimator;
import android.app.ActivityManager;
import android.app.AppOpsManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.StorageStats;
import android.app.usage.StorageStatsManager;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.storage.StorageManager;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import java.io.File;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.IntConsumer;

/** IMZYY KNOX Game Turbo v6.0 - compact floating panel with separate icon menus. */
public class FloatingService extends Service {
    static boolean running;
    private static final int CY = 0xFF53E9FF, BL = 0xFF3C86FF, PU = 0xFF9270FF, OK = 0xFF55E7A9, WARN = 0xFFFFC857, BAD = 0xFFFF6B6B, MUTE = 0xFF8394A9;
    private static final int[] TARGETS = {10, 30, 60, 90, 0};
    private static final String[] TAB_ICON = {"⚡", "🎞", "🎨", "🧰", "📱", "🧹", "ℹ"};
    private static final String[] TAB_NAME = {"HOME", "FPS", "STYLE", "TOOLS", "APPS", "CACHE", "INFO"};
    private static final int TAB_APPS = 4, TAB_CACHE = 5;

    private WindowManager wm;
    private SharedPreferences sp;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final FpsEngine.Meter meter = new FpsEngine.Meter();
    private WindowManager.LayoutParams bp, pp;
    private TextView bubble, status;
    private LinearLayout panel;
    private FrameLayout content;
    private final ArrayList<LinearLayout> navItems = new ArrayList<>();
    private final ArrayList<TextView> fpsBtns = new ArrayList<>();
    private final ArrayList<TextView> toggles = new ArrayList<>();
    private TextView tRam, tBat, tTemp, tTherm, tHz;
    private View barFill, barRest;
    private LinearLayout appList;
    private TextView appSummary;
    private int curTab = 0, tickCount = 0, scanGen = 0;
    private boolean loadingApps = false;
    private final ArrayList<AppRow> lastRows = new ArrayList<>();

    private static class AppRow {
        String label, pkg; long cache; long last;
        AppRow(String l, String p, long c, long t) { label = l; pkg = p; cache = c; last = t; }
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            tickCount++;
            refresh();
            if ((curTab == TAB_APPS || curTab == TAB_CACHE) && tickCount % 3 == 0) reloadApps();
            ui.postDelayed(this, 2000);
        }
    };
    private final BroadcastReceiver orientationReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) { ui.postDelayed(FloatingService.this::reflow, 150); }
    };

    // ------------------------------------------------------------ lifecycle
    @Override public void onCreate() {
        super.onCreate();
        running = true;
        sp = getSharedPreferences("turbo", MODE_PRIVATE);
        startForeground(7, notification());
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        IntentFilter cfg = new IntentFilter(Intent.ACTION_CONFIGURATION_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(orientationReceiver, cfg, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(orientationReceiver, cfg);
        CleanerService.listener = this::onCleaner;
        showBubble();
    }

    @Override public int onStartCommand(Intent i, int flags, int id) {
        if (i != null && "STOP".equals(i.getAction())) { stopSelf(); return START_NOT_STICKY; }
        return START_STICKY;
    }

    @Override public void onDestroy() {
        running = false;
        CleanerService.listener = null;
        try { unregisterReceiver(orientationReceiver); } catch (Exception ignored) { }
        ui.removeCallbacksAndMessages(null);
        meter.stop();
        try { if (bubble != null) wm.removeView(bubble); } catch (Exception ignored) { }
        try { if (panel != null) wm.removeView(panel); } catch (Exception ignored) { }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }

    private Notification notification() {
        String ch = "imzyy_turbo";
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(
                new NotificationChannel(ch, "Game Turbo Panel", NotificationManager.IMPORTANCE_LOW));
        PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, FloatingService.class).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, ch).setContentTitle("IMZYY KNOX Game Turbo")
                .setContentText("Floating hub aktif • tap bubble ⚡")
                .setSmallIcon(android.R.drawable.ic_menu_manage)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "STOP", stop).build()).build();
    }

    // ------------------------------------------------------------ ui helpers
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }

    private GradientDrawable bg(int c1, int c2, int r, int stroke) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        g.setCornerRadius(dp(r));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView txt(String s, int sz, int c, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sz); t.setTextColor(c);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        return t;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private LinearLayout.LayoutParams mt(int top) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(top); return p; }
    private LinearLayout.LayoutParams w1(boolean first) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1); if (!first) p.leftMargin = dp(5); return p; }

    private WindowManager.LayoutParams lp(int w, int h) {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        return p;
    }

    private void status(String s, int c) {
        if (status == null) return;
        status.setText("✦ " + s);
        status.setTextColor(c);
        status.setBackground(bg(c == OK ? 0xFF123B42 : c == WARN ? 0xFF40351F : 0xFF18284A, 0xFF10182D, 10,
                c == OK ? 0x6655E7A9 : c == WARN ? 0x66FFC857 : 0x665C8DFF));
    }

    private void open(Intent i) {
        try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); }
        catch (Exception e) { status("Tidak tersedia di perangkat ini", WARN); }
    }

    private void openWriteSettings() { open(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName()))); }

    private LinearLayout newPage() {
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, dp(2), 0, dp(6));
        sv.addView(col, new ScrollView.LayoutParams(-1, -2));
        content.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        return col;
    }

    private TextView title(String s) {
        TextView t = txt(s, 8, MUTE, true);
        t.setLetterSpacing(.14f);
        t.setPadding(dp(2), dp(10), 0, dp(2));
        return t;
    }

    private TextView note(String s) {
        TextView t = txt(s, 8, MUTE, false);
        t.setLineSpacing(0, 1.12f);
        return t;
    }

    private TextView tile(LinearLayout r, String label, boolean first) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER); c.setPadding(0, dp(8), 0, dp(8));
        c.setBackground(bg(0xFF0D1723, 0xFF08121C, 12, 0x2253E9FF));
        TextView l = txt(label, 7, MUTE, false); l.setLetterSpacing(.12f);
        TextView v = txt("--", 15, 0xFFFFFFFF, true);
        c.addView(l); c.addView(v);
        r.addView(c, w1(first));
        return v;
    }

    private TextView btn(LinearLayout r, String s, boolean first, Runnable a) {
        TextView t = txt(s, 9, 0xFFBFF8FF, true);
        t.setGravity(Gravity.CENTER); t.setPadding(dp(3), dp(10), dp(3), dp(10));
        t.setMaxLines(1); t.setEllipsize(TextUtils.TruncateAt.END);
        t.setBackground(bg(0xFF12344B, 0xFF102140, 11, 0x4453E9FF));
        t.setOnClickListener(v -> a.run());
        r.addView(t, w1(first));
        return t;
    }

    private void bigButton(LinearLayout parent, String s, Runnable a) {
        TextView t = txt(s, 12, 0xFF03131C, true);
        t.setGravity(Gravity.CENTER); t.setLetterSpacing(.08f); t.setPadding(0, dp(12), 0, dp(12));
        t.setBackground(bg(CY, PU, 14, 0));
        t.setOnClickListener(v -> a.run());
        parent.addView(t, mt(8));
    }

    private void paintChips(List<TextView> chips, int sel) {
        for (int i = 0; i < chips.size(); i++) {
            TextView t = chips.get(i); boolean on = i == sel;
            t.setTextColor(on ? 0xFF03131C : 0xFFBFF8FF);
            t.setBackground(on ? bg(CY, PU, 10, 0) : bg(0xFF12344B, 0xFF102140, 10, 0x3353E9FF));
        }
    }

    /** Segmented selector (replaces Spinner, which does not work well inside an overlay). */
    private void chips(LinearLayout parent, final String key, String[] labels) {
        LinearLayout line = row();
        final ArrayList<TextView> cs = new ArrayList<>();
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            TextView t = txt(labels[i], 8, 0xFFBFF8FF, true);
            t.setGravity(Gravity.CENTER); t.setPadding(0, dp(9), 0, dp(9)); t.setMaxLines(1);
            t.setOnClickListener(v -> { sp.edit().putInt(key, idx).apply(); paintChips(cs, idx); });
            cs.add(t); line.addView(t, w1(i == 0));
        }
        paintChips(cs, sp.getInt(key, 0));
        parent.addView(line, mt(6));
    }

    private void toggle(LinearLayout r, final String key, final String label, boolean first) {
        TextView t = txt(label, 9, 0xFFA4B7CA, true);
        t.setGravity(Gravity.CENTER); t.setPadding(dp(3), dp(10), dp(3), dp(10)); t.setMaxLines(1);
        t.setTag(new String[]{key, label});
        t.setOnClickListener(v -> {
            boolean n = !sp.getBoolean(key, false);
            if (key.equals("dnd")) dnd(n); else if (key.equals("bright")) bright(n); else awake(n);
            paintAll();
        });
        toggles.add(t); paintToggle(t);
        r.addView(t, w1(first));
    }

    private void paintToggle(TextView t) {
        String[] k = (String[]) t.getTag();
        boolean on = sp.getBoolean(k[0], false);
        t.setText((on ? "● " : "○ ") + k[1]);
        t.setTextColor(on ? 0xFF03131C : 0xFFA4B7CA);
        t.setBackground(on ? bg(CY, BL, 11, 0) : bg(0xFF0D1723, 0xFF08121C, 11, 0x33FFFFFF));
    }

    private void paintAll() { for (TextView t : toggles) paintToggle(t); }

    private void smartSwitch(LinearLayout parent, final String key, String name, String detail) {
        LinearLayout item = row();
        item.setPadding(dp(9), dp(7), dp(7), dp(7));
        item.setBackground(bg(0xFF0B1521, 0xFF0A1019, 11, 0x223FBCD4));
        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL);
        col.addView(txt(name, 9, 0xFFEAF5FF, true));
        col.addView(txt(detail, 7, MUTE, false));
        final Switch sw = new Switch(this);
        sw.setChecked(sp.getBoolean(key, false));
        final boolean[] guard = new boolean[1];
        sw.setOnCheckedChangeListener((btnView, on) -> {
            if (guard[0]) return;
            if ("frame_opt".equals(key)) {
                sp.edit().putBoolean(key, on).apply();
                if (on) setFps(0); else { FpsEngine.reset(this); status("Frame optimization off • refresh otomatis", WARN); }
            } else if ("battery_profile".equals(key)) {
                if (!ProfileEngine.batteryBalance(this, on)) {
                    guard[0] = true; sw.setChecked(!on); guard[0] = false;
                    openWriteSettings();
                    status("Izinkan Ubah setelan sistem, lalu aktifkan lagi", WARN);
                } else {
                    sp.edit().putBoolean(key, on).apply();
                    status(on ? "Battery Balance aktif" : "Pengaturan layar dipulihkan", OK);
                }
            } else if ("touch_profile".equals(key)) {
                sp.edit().putBoolean(key, on).apply();
                open(new Intent(Settings.ACTION_DISPLAY_SETTINGS));
                status("Atur Touch sensitivity di menu layar jika tersedia", WARN);
            } else sp.edit().putBoolean(key, on).apply();
        });
        item.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        item.addView(sw);
        parent.addView(item, mt(6));
    }

    // ------------------------------------------------------------ bubble
    private void showBubble() {
        int s = dp(52);
        bubble = txt("⚡", 22, 0xFFFFFFFF, false);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{CY, BL, PU});
        g.setShape(GradientDrawable.OVAL); g.setStroke(dp(2), 0x88FFFFFF);
        bubble.setBackground(g);
        bp = lp(s, s); bp.x = dp(4); bp.y = dp(220);
        int f0 = sp.getInt("fps", -1);
        if (f0 >= 0) FpsEngine.prefer(bp, this, FpsEngine.pick(this, f0));
        applyAwake();
        bubble.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy; float tx, ty; boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = bp.x; sy = bp.y; tx = e.getRawX(); ty = e.getRawY(); moved = false; bubble.setAlpha(1f); return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - tx, dy = e.getRawY() - ty;
                        if (Math.abs(dx) + Math.abs(dy) > dp(6)) moved = true;
                        if (moved) { bp.x = sx + (int) dx; bp.y = sy + (int) dy; try { wm.updateViewLayout(bubble, bp); } catch (Exception ignored) { } }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) openPanel(); else snap();
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        snap(); return true;
                    default: return true;
                }
            }
        });
        wm.addView(bubble, bp);
    }

    private void snap() {
        DisplayMetrics m = getResources().getDisplayMetrics();
        int size = dp(52);
        int to = (bp.x + size / 2 < m.widthPixels / 2) ? dp(4) : m.widthPixels - size - dp(4);
        bp.y = Math.max(dp(8), Math.min(bp.y, m.heightPixels - size - dp(8)));
        ValueAnimator a = ValueAnimator.ofInt(bp.x, to);
        a.setDuration(200);
        a.addUpdateListener(va -> { bp.x = (Integer) va.getAnimatedValue(); try { wm.updateViewLayout(bubble, bp); } catch (Exception ignored) { } });
        a.start();
        bubble.setAlpha(.85f);
    }

    // ------------------------------------------------------------ panel shell
    private int[] panelSize() {
        DisplayMetrics m = getResources().getDisplayMetrics();
        boolean land = m.widthPixels > m.heightPixels;
        int w = Math.min(dp(300), (int) (m.widthPixels * .88f));
        int h = Math.min((int) (m.heightPixels * (land ? .86f : .56f)), dp(420));
        return new int[]{w, h};
    }

    private void openPanel() {
        if (panel != null) return;
        bubble.setVisibility(View.GONE);
        int[] sz = panelSize();

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(8), dp(10), dp(8));
        box.setBackground(bg(0xF2182248, 0xF2060B18, 22, 0x665C8DFF));

        // header = drag handle
        LinearLayout head = row();
        head.setPadding(0, 0, 0, dp(4));
        TextView logo = txt("⚡", 18, CY, true); logo.setPadding(0, 0, dp(8), 0);
        LinearLayout titles = new LinearLayout(this); titles.setOrientation(LinearLayout.VERTICAL);
        TextView t1 = txt("GAME TURBO", 13, 0xFFFFFFFF, true); t1.setLetterSpacing(.1f);
        TextView t2 = txt("BY IMZYYKNOX • DRAG DI SINI ⇕", 7, 0xFF9CAED0, false); t2.setLetterSpacing(.08f);
        titles.addView(t1); titles.addView(t2);
        head.addView(logo); head.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        TextView min = txt("—", 14, 0xFFBFF8FF, true); min.setPadding(dp(12), dp(4), dp(12), dp(4)); min.setOnClickListener(v -> closePanel());
        TextView close = txt("✕", 14, BAD, true); close.setPadding(dp(8), dp(4), dp(4), dp(4)); close.setOnClickListener(v -> stopSelf());
        head.addView(min); head.addView(close);
        head.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy; float tx, ty;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (pp == null || panel == null) return false;
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = pp.x; sy = pp.y; tx = e.getRawX(); ty = e.getRawY(); return true;
                    case MotionEvent.ACTION_MOVE:
                        DisplayMetrics m = getResources().getDisplayMetrics();
                        pp.x = Math.max(0, Math.min(m.widthPixels - pp.width, sx + (int) (e.getRawX() - tx)));
                        pp.y = Math.max(0, Math.min(m.heightPixels - pp.height, sy + (int) (e.getRawY() - ty)));
                        try { wm.updateViewLayout(panel, pp); } catch (Exception ignored) { }
                        return true;
                    default: return true;
                }
            }
        });
        box.addView(head);

        status = txt("✦ SIAP", 9, 0xFFBFEAFF, true);
        status.setPadding(dp(9), dp(6), dp(9), dp(6));
        status.setSingleLine(true); status.setEllipsize(TextUtils.TruncateAt.END);
        status.setBackground(bg(0xFF18284A, 0xFF10182D, 10, 0x665C8DFF));
        box.addView(status, mt(2));

        content = new FrameLayout(this);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, 0, 1);
        clp.topMargin = dp(4);
        box.addView(content, clp);

        // bottom icon navigation
        LinearLayout nav = row();
        nav.setPadding(0, dp(4), 0, 0);
        navItems.clear();
        for (int i = 0; i < TAB_NAME.length; i++) {
            final int idx = i;
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL); item.setGravity(Gravity.CENTER);
            item.setPadding(0, dp(5), 0, dp(4));
            item.addView(txt(TAB_ICON[i], 15, 0xFFFFFFFF, false));
            TextView lb = txt(TAB_NAME[i], 6, 0xFFBFEAFF, true);
            item.addView(lb);
            item.setOnClickListener(v -> showTab(idx));
            LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(0, -2, 1);
            if (i > 0) nlp.leftMargin = dp(2);
            nav.addView(item, nlp);
            navItems.add(item);
        }
        box.addView(nav);

        panel = box;
        pp = lp(sz[0], sz[1]);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        pp.x = (dm.widthPixels - sz[0]) / 2; pp.y = dp(70);
        applyAwake();
        box.setAlpha(0f); box.setScaleX(.95f); box.setScaleY(.95f);
        wm.addView(panel, pp);
        box.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start();
        showTab(curTab);
        ui.removeCallbacks(tick);
        ui.post(tick);
    }

    private void closePanel() {
        ui.removeCallbacks(tick);
        stopLive();
        if (panel != null) { try { wm.removeView(panel); } catch (Exception ignored) { } }
        panel = null; pp = null; status = null; content = null;
        if (bubble != null) bubble.setVisibility(View.VISIBLE);
    }

    private void stopLive() {
        meter.stop();
        tRam = tBat = tTemp = tTherm = tHz = null;
        barFill = barRest = null;
        appList = null; appSummary = null; loadingApps = false;
        fpsBtns.clear(); toggles.clear();
        scanGen++;
    }

    private void paintNav() {
        for (int i = 0; i < navItems.size(); i++) {
            boolean on = i == curTab;
            navItems.get(i).setBackground(on ? bg(0xFF3C86FF, 0xFF9270FF, 10, 0) : bg(0xFF18284A, 0xFF10182D, 10, 0x334D9DFF));
        }
    }

    private void showTab(int i) {
        if (content == null) return;
        curTab = i;
        stopLive();
        content.removeAllViews();
        paintNav();
        switch (i) {
            case 0: pageHome(); break;
            case 1: pageFps(); break;
            case 2: pageStyle(); break;
            case 3: pageTools(); break;
            case TAB_APPS: pageApps(true); break;
            case TAB_CACHE: pageApps(false); break;
            default: pageInfo(); break;
        }
    }

    // ------------------------------------------------------------ pages
    private void pageHome() {
        LinearLayout c = newPage();
        LinearLayout r1 = row(); tRam = tile(r1, "RAM", true); tBat = tile(r1, "BATERAI", false); c.addView(r1, mt(2));
        LinearLayout r2 = row(); tTemp = tile(r2, "SUHU", true); tTherm = tile(r2, "THERMAL", false); c.addView(r2, mt(5));
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackground(bg(0xFF172635, 0xFF172635, 3, 0));
        barFill = new View(this); barFill.setBackground(bg(CY, PU, 3, 0));
        barRest = new View(this);
        bar.addView(barFill, new LinearLayout.LayoutParams(0, dp(6), 50));
        bar.addView(barRest, new LinearLayout.LayoutParams(0, dp(6), 50));
        c.addView(bar, mt(8));
        bigButton(c, "⚡  TURBO BOOST", () -> boost(0));
        LinearLayout tg = row();
        toggle(tg, "dnd", "DND", true); toggle(tg, "awake", "AWAKE", false); toggle(tg, "bright", "BRIGHT", false);
        c.addView(tg, mt(8));
        c.addView(note("Turbo: bersihkan cache IMZYY, minta stop proses latar, layar tetap menyala, DND bila diizinkan."), mt(6));
        refresh();
    }

    private void pageFps() {
        LinearLayout c = newPage();
        LinearLayout live = row();
        TextView ll = txt("LIVE", 8, MUTE, true); ll.setLetterSpacing(.2f);
        tHz = txt("-- Hz", 24, CY, true); tHz.setPadding(dp(10), 0, 0, 0);
        live.addView(ll); live.addView(tHz);
        c.addView(live, mt(4));
        meter.start(tHz);
        c.addView(title("FPS TARGET"), mt(0));
        LinearLayout fr = row();
        for (int i = 0; i < TARGETS.length; i++) {
            final int tgt = TARGETS[i];
            fpsBtns.add(btn(fr, tgt == 0 ? "MAX" : String.valueOf(tgt), i == 0, () -> setFps(tgt)));
        }
        c.addView(fr, mt(2));
        c.addView(title("PRECISION"), mt(0));
        final TextView readout = txt("90 Hz", 18, CY, true);
        c.addView(readout, mt(0));
        SeekBar slider = new SeekBar(this);
        slider.setMax(110); slider.setProgress(80);
        slider.setProgressTintList(android.content.res.ColorStateList.valueOf(CY));
        slider.setThumbTintList(android.content.res.ColorStateList.valueOf(PU));
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean user) {
                int req = 10 + p, act = FpsEngine.pick(FloatingService.this, req);
                readout.setText(act + " Hz" + (act != req ? " • terdekat" : ""));
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { int val = 10 + sb.getProgress(); setFps(val >= 115 ? 0 : val); }
        });
        c.addView(slider, mt(2));
        btn1(c, "RESET AUTO", () -> { FpsEngine.reset(this); paintFps(); status("Refresh rate kembali otomatis", MUTE); });
        c.addView(note("Mengunci laju layar (nyata). Aplikasi biasa tidak bisa memaksa FPS di dalam game lain tanpa root."), mt(6));
        paintFps();
    }

    private void btn1(LinearLayout parent, String s, Runnable a) {
        LinearLayout r = row();
        btn(r, s, true, a);
        parent.addView(r, mt(8));
    }

    private void pageStyle() {
        LinearLayout c = newPage();
        c.addView(title("RENDER / DISPLAY PROFILE"), mt(0));
        chips(c, "render_profile", new String[]{"AUTO", "LOW", "60Hz", "MAX"});
        btn1(c, "APPLY DISPLAY PROFILE", this::applyRenderProfile);
        c.addView(title("GRAPHICS PRESET"), mt(4));
        chips(c, "graphics_profile", new String[]{"AUTO", "ULTRA", "BAL", "PERF", "SAFE"});
        btn1(c, "APPLY GRAPHIC PRESET", () -> {
            String res = ProfileEngine.applyGraphics(this, sp.getInt("graphics_profile", 0));
            if (res.startsWith("Izin")) openWriteSettings();
            status(res, res.startsWith("Refresh") ? OK : WARN);
        });
        c.addView(note("Mengubah refresh rate layar yang didukung. Tekstur/shader/renderer tetap diatur dari dalam game."), mt(4));
        c.addView(title("SMART SWITCH"), mt(2));
        smartSwitch(c, "frame_opt", "FRAME RATE OPT", "Refresh rate tertinggi yang didukung.");
        smartSwitch(c, "thermal_guard", "THERMAL GUARD", "Waspada 42°C • tahan boost 44°C.");
        smartSwitch(c, "battery_profile", "BATTERY BALANCE", "Brightness & refresh rate turun.");
        smartSwitch(c, "touch_profile", "TOUCH RESPONSE", "Buka setelan sentuhan Samsung.");
    }

    private void pageTools() {
        LinearLayout c = newPage();
        String game = sp.getString("saved_game_name", "");
        c.addView(title("GAME SESSION"), mt(0));
        c.addView(txt(game.isEmpty() ? "Belum ada game dipilih" : "🎮 " + game, 11, 0xFFFFFFFF, true), mt(2));
        LinearLayout g1 = row();
        btn(g1, "PILIH GAME", true, this::pageGamePicker);
        btn(g1, "AUTO START", false, this::startGameSession);
        c.addView(g1, mt(6));
        c.addView(title("BOOST"), mt(4));
        LinearLayout b1 = row();
        btn(b1, "CLEAN RAM", true, () -> boost(1)); btn(b1, "CACHE IMZYY", false, () -> boost(2)); btn(b1, "PING", false, this::ping);
        c.addView(b1, mt(2));
        c.addView(title("SHORTCUT"), mt(4));
        LinearLayout s1 = row();
        btn(s1, "DISPLAY", true, () -> open(new Intent(Settings.ACTION_DISPLAY_SETTINGS)));
        btn(s1, "BATERAI", false, () -> open(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)));
        btn(s1, "STORAGE", false, () -> open(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)));
        c.addView(s1, mt(2));
        LinearLayout s2 = row();
        btn(s2, "VOICE", true, () -> open(new Intent(this, VoiceStudioActivity.class)));
        btn(s2, "BUKA APP", false, () -> open(new Intent(this, MainActivity.class)));
        btn(s2, "IZIN APP", false, () -> open(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))));
        c.addView(s2, mt(6));
    }

    private void pageGamePicker() {
        if (content == null) return;
        stopLive();
        content.removeAllViews();
        LinearLayout c = newPage();
        LinearLayout head = row();
        TextView back = txt("‹ KEMBALI", 9, CY, true); back.setPadding(0, dp(4), dp(10), dp(4)); back.setOnClickListener(v -> showTab(3));
        head.addView(back); head.addView(txt("PILIH GAME", 10, 0xFFFFFFFF, true));
        c.addView(head, mt(0));
        final PackageManager pm = getPackageManager();
        List<ResolveInfo> apps = pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0);
        Collections.sort(apps, (x, y) -> String.CASE_INSENSITIVE_ORDER.compare(String.valueOf(x.loadLabel(pm)), String.valueOf(y.loadLabel(pm))));
        HashSet<String> seen = new HashSet<>();
        for (ResolveInfo ri : apps) {
            final String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
            final String label = String.valueOf(ri.loadLabel(pm));
            TextView t = txt(label, 10, 0xFFFFFFFF, true);
            t.setPadding(dp(10), dp(10), dp(10), dp(10));
            t.setBackground(bg(0xFF14233D, 0xFF10182D, 10, 0x334F80C8));
            t.setOnClickListener(v -> {
                sp.edit().putString("saved_game_package", pkg).putString("saved_game_name", label).apply();
                showTab(3);
                status("Tersimpan: " + label, OK);
            });
            c.addView(t, mt(4));
        }
    }

    private void pageInfo() {
        LinearLayout c = newPage();
        TextView logo = txt("⚡", 34, CY, true); logo.setGravity(Gravity.CENTER);
        c.addView(logo, mt(8));
        TextView n = txt("GAME TURBO", 18, 0xFFFFFFFF, true); n.setGravity(Gravity.CENTER); n.setLetterSpacing(.12f);
        c.addView(n, mt(0));
        TextView by = txt("BY IMZYYKNOX", 11, CY, true); by.setGravity(Gravity.CENTER); by.setLetterSpacing(.2f);
        c.addView(by, mt(2));
        TextView ver = txt("Galaxy Performance Suite • v6.0", 8, MUTE, false); ver.setGravity(Gravity.CENTER);
        c.addView(ver, mt(4));
        c.addView(title("CREDIT"), mt(10));
        c.addView(txt("Game Turbo by ImzyyKnox\nDesain, kode & konsep: ImzyyKnox", 10, 0xFFD0DCE8, false), mt(0));
        c.addView(title("CATATAN"), mt(6));
        c.addView(note("• Refresh rate layar: nyata, via izin Ubah setelan sistem.\n• Clear cache & Force Stop aplikasi lain: lewat IMZYY Cleaner (Aksesibilitas) yang menekan tombol di Info Aplikasi seperti dilakukan manual.\n• Daftar app aktif memakai Usage Access (aplikasi yang dipakai ≤ 2 jam terakhir).\n• Aplikasi tidak bisa mengubah renderer atau FPS internal game tanpa root."), mt(0));
    }

    // ------------------------------------------------------------ apps / cache pages
    private boolean hasUsageAccess() {
        try {
            AppOpsManager ops = (AppOpsManager) getSystemService(APP_OPS_SERVICE);
            return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), getPackageName()) == AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) { return false; }
    }

    private String sizeText(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024L * 1024) return String.format(Locale.US, "%.0f KB", b / 1024d);
        if (b < 1024L * 1024 * 1024) return String.format(Locale.US, "%.1f MB", b / (1024d * 1024));
        return String.format(Locale.US, "%.2f GB", b / (1024d * 1024 * 1024));
    }

    private void pageApps(final boolean runningMode) {
        LinearLayout c = newPage();
        c.addView(title(runningMode ? "APLIKASI AKTIF (≤ 2 JAM) • STOP / CLEAR" : "SEMUA APLIKASI BERCACHE • CLEAR"), mt(0));
        if (CleanerService.enabled()) {
            c.addView(txt("✓ IMZYY Cleaner aktif • CLEAR/STOP otomatis", 8, OK, true), mt(0));
        } else {
            TextView warn = txt("⚠ Aktifkan IMZYY Cleaner (Aksesibilitas) agar CLEAR/STOP berjalan otomatis. Ketuk di sini.", 8, WARN, true);
            warn.setPadding(dp(8), dp(6), dp(8), dp(6));
            warn.setBackground(bg(0xFF40351F, 0xFF2B2415, 10, 0x66FFC857));
            warn.setOnClickListener(v -> { open(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); status("Cari 'IMZYY Cleaner' lalu aktifkan", WARN); });
            c.addView(warn, mt(2));
        }
        LinearLayout acts = row();
        btn(acts, "REFRESH", true, this::reloadApps);
        if (runningMode) btn(acts, "STOP SEMUA", false, this::stopAll); else btn(acts, "CLEAR SEMUA", false, this::clearAll);
        c.addView(acts, mt(6));
        appSummary = txt("Memuat…", 8, CY, true);
        c.addView(appSummary, mt(6));
        appList = new LinearLayout(this);
        appList.setOrientation(LinearLayout.VERTICAL);
        c.addView(appList, mt(2));
        lastRows.clear();
        reloadApps();
    }

    private void reloadApps() {
        if (appList == null || loadingApps) return;
        if (!hasUsageAccess()) {
            appList.removeAllViews();
            if (appSummary != null) appSummary.setText("Usage Access belum aktif");
            TextView t = txt("IZINKAN USAGE ACCESS", 10, 0xFF03131C, true);
            t.setGravity(Gravity.CENTER); t.setPadding(0, dp(12), 0, dp(12)); t.setBackground(bg(CY, PU, 12, 0));
            t.setOnClickListener(v -> open(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)));
            appList.addView(t, mt(4));
            return;
        }
        loadingApps = true;
        final int gen = ++scanGen;
        final boolean runningMode = curTab == TAB_APPS;
        new Thread(() -> {
            final ArrayList<AppRow> rows = scanApps(runningMode);
            ui.post(() -> {
                loadingApps = false;
                if (gen != scanGen || appList == null) return;
                lastRows.clear(); lastRows.addAll(rows);
                renderApps(runningMode);
            });
        }).start();
    }

    private ArrayList<AppRow> scanApps(boolean runningMode) {
        PackageManager pm = getPackageManager();
        StorageStatsManager sm = (StorageStatsManager) getSystemService(STORAGE_STATS_SERVICE);
        UsageStatsManager um = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
        long now = System.currentTimeMillis();
        HashMap<String, Long> last = new HashMap<>();
        try {
            List<UsageStats> us = um.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 24L * 3600 * 1000, now);
            if (us != null) for (UsageStats u : us) {
                Long old = last.get(u.getPackageName());
                if (old == null || u.getLastTimeUsed() > old) last.put(u.getPackageName(), u.getLastTimeUsed());
            }
        } catch (Exception ignored) { }
        ArrayList<String> pkgs = new ArrayList<>();
        if (runningMode) {
            for (Map.Entry<String, Long> en : last.entrySet())
                if (now - en.getValue() <= 2L * 3600 * 1000 && en.getValue() > 0) pkgs.add(en.getKey());
        } else {
            for (ApplicationInfo ai : pm.getInstalledApplications(0)) pkgs.add(ai.packageName);
        }
        ArrayList<AppRow> out = new ArrayList<>();
        for (String pkg : pkgs) {
            if (pkg.equals(getPackageName())) continue;
            try {
                if (runningMode && pm.getLaunchIntentForPackage(pkg) == null) continue;
                long cache = 0;
                try {
                    StorageStats st = sm.queryStatsForPackage(StorageManager.UUID_DEFAULT, pkg, android.os.Process.myUserHandle());
                    cache = st.getCacheBytes();
                } catch (Exception ignored) { }
                if (!runningMode && cache <= 0) continue;
                String label = String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
                Long lt = last.get(pkg);
                out.add(new AppRow(label, pkg, cache, lt == null ? 0 : lt));
            } catch (Exception ignored) { }
        }
        if (runningMode) Collections.sort(out, (x, y) -> Long.compare(y.last, x.last));
        else Collections.sort(out, (x, y) -> Long.compare(y.cache, x.cache));
        return out;
    }

    private void renderApps(boolean runningMode) {
        if (appList == null) return;
        appList.removeAllViews();
        long total = 0;
        for (AppRow r : lastRows) total += r.cache;
        if (appSummary != null) appSummary.setText(lastRows.size() + " aplikasi • total cache " + sizeText(total) + " • auto-refresh 6 dtk");
        if (lastRows.isEmpty()) { appList.addView(note(runningMode ? "Tidak ada aplikasi aktif terdeteksi." : "Tidak ada cache terdeteksi."), mt(6)); return; }
        long now = System.currentTimeMillis();
        int shown = 0;
        for (AppRow r : lastRows) {
            if (shown++ >= 60) break;
            final AppRow ar = r;
            LinearLayout item = row();
            item.setPadding(dp(8), dp(6), dp(5), dp(6));
            item.setBackground(bg(0xFF14233D, 0xFF10182D, 10, 0x334F80C8));
            LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL);
            TextView nm = txt(ar.label, 10, 0xFFFFFFFF, true); nm.setSingleLine(true); nm.setEllipsize(TextUtils.TruncateAt.END);
            String sub = "cache " + sizeText(ar.cache);
            if (runningMode && ar.last > 0) sub += " • " + Math.max(0, (now - ar.last) / 60000) + " mnt lalu";
            TextView sb = txt(sub, 8, 0xFF9DB0C6, false); sb.setSingleLine(true);
            col.addView(nm); col.addView(sb);
            item.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
            if (runningMode) item.addView(smallBtn("STOP", BAD, () -> stopApp(ar.pkg, ar.label)));
            item.addView(smallBtn("CLEAR", CY, () -> clearCache(ar.pkg, ar.label)));
            appList.addView(item, mt(4));
        }
    }

    private TextView smallBtn(String s, int color, Runnable a) {
        TextView t = txt(s, 8, color, true);
        t.setGravity(Gravity.CENTER); t.setPadding(dp(8), dp(8), dp(8), dp(8));
        t.setBackground(bg(0xFF183B50, 0xFF12283B, 8, 0));
        t.setOnClickListener(v -> a.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.leftMargin = dp(4);
        t.setLayoutParams(p);
        return t;
    }

    private void stopApp(String pkg, String label) {
        try { ((ActivityManager) getSystemService(ACTIVITY_SERVICE)).killBackgroundProcesses(pkg); } catch (Exception ignored) { }
        if (CleanerService.enabled()) {
            CleanerService.enqueue(pkg, CleanerService.FORCE_STOP, label);
            status("STOP " + label + " • diproses…", WARN);
        } else {
            status("Permintaan stop dikirim: " + label + " • aktifkan Cleaner untuk Force Stop", WARN);
        }
    }

    private void clearCache(String pkg, String label) {
        if (CleanerService.enabled()) {
            CleanerService.enqueue(pkg, CleanerService.CLEAR_CACHE, label);
            status("CLEAR cache " + label + " • diproses…", WARN);
        } else {
            status("Aktifkan IMZYY Cleaner dulu untuk clear cache otomatis", WARN);
            open(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        }
    }

    private void stopAll() {
        if (lastRows.isEmpty()) { status("Belum ada aplikasi di daftar", WARN); return; }
        int n = 0;
        for (AppRow r : new ArrayList<>(lastRows)) { stopApp(r.pkg, r.label); n++; }
        status(n + " aplikasi diantrikan untuk STOP", WARN);
    }

    private void clearAll() {
        if (!CleanerService.enabled()) { status("Aktifkan IMZYY Cleaner dulu", WARN); open(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return; }
        int n = 0;
        for (AppRow r : new ArrayList<>(lastRows)) { if (r.cache > 0) { CleanerService.enqueue(r.pkg, CleanerService.CLEAR_CACHE, r.label); n++; } }
        status(n + " aplikasi diantrikan untuk CLEAR cache", WARN);
    }

    private void onCleaner(String msg, boolean ok, boolean done) {
        status(msg + (done ? "" : " • lanjut…"), ok ? OK : WARN);
        if (done && (curTab == TAB_APPS || curTab == TAB_CACHE)) reloadApps();
    }

    // ------------------------------------------------------------ live stats
    private ActivityManager.MemoryInfo mem() {
        ActivityManager.MemoryInfo m = new ActivityManager.MemoryInfo();
        ((ActivityManager) getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(m);
        return m;
    }

    private void refresh() {
        if (panel == null || curTab != 0 || tRam == null) return;
        ActivityManager.MemoryInfo mi = mem();
        int used = (int) (100 - mi.availMem * 100 / Math.max(1, mi.totalMem));
        tRam.setText(used + "%"); tRam.setTextColor(used > 85 ? BAD : used > 70 ? WARN : OK);
        if (barFill != null && barRest != null) {
            ((LinearLayout.LayoutParams) barFill.getLayoutParams()).weight = Math.max(1, used);
            ((LinearLayout.LayoutParams) barRest.getLayoutParams()).weight = Math.max(1, 100 - used);
            barFill.requestLayout();
        }
        Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (b != null) {
            int lv = b.getIntExtra("level", 0) * 100 / Math.max(1, b.getIntExtra("scale", 100));
            float t = b.getIntExtra("temperature", 0) / 10f;
            tBat.setText(lv + "%"); tTemp.setText(t + "°"); tTemp.setTextColor(t >= 42 ? BAD : t >= 38 ? WARN : OK);
        }
        if (Build.VERSION.SDK_INT >= 29) {
            int ts = ((PowerManager) getSystemService(POWER_SERVICE)).getCurrentThermalStatus();
            tTherm.setText(ts <= 0 ? "COOL" : ts == 1 ? "WARM" : ts == 2 ? "WARM+" : ts == 3 ? "HOT" : "CRIT");
            tTherm.setTextColor(ts <= 0 ? OK : ts <= 2 ? WARN : BAD);
        } else tTherm.setText("N/A");
    }

    // ------------------------------------------------------------ actions
    private int killBg() {
        if (Build.VERSION.SDK_INT >= 34) return 0;
        PackageManager pm = getPackageManager();
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        int n = 0;
        for (ResolveInfo r : pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)) {
            String p = r.activityInfo.packageName;
            if (p.equals(getPackageName()) || (r.activityInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
            am.killBackgroundProcesses(p); n++;
        }
        return n;
    }

    private boolean thermalBlocked() {
        if (!sp.getBoolean("thermal_guard", false)) return false;
        Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        float temp = battery == null ? 0 : battery.getIntExtra("temperature", 0) / 10f;
        if (temp >= 44f) { status("THERMAL GUARD: ditahan • suhu " + temp + "°C", WARN); return true; }
        if (temp >= 42f) status("THERMAL GUARD: suhu tinggi " + temp + "°C", WARN);
        return false;
    }

    private void boost(final int mode) { // 0 = turbo, 1 = RAM only, 2 = cache only
        if (thermalBlocked()) return;
        status("⚡ Boosting…", WARN);
        new Thread(() -> {
            long before = mem().availMem;
            int n = mode < 2 ? killBg() : 0;
            long kb = 0;
            if (mode != 1) { kb = fileSize(getCacheDir()) >> 10; wipe(getCacheDir()); }
            try { Thread.sleep(900); } catch (Exception ignored) { }
            final long mb = Math.max(0, (mem().availMem - before) >> 20);
            final int fn = n; final long fk = kb;
            ui.post(() -> {
                if (mode == 0) {
                    awake(true);
                    NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                    if (nm.isNotificationPolicyAccessGranted() && !sp.getBoolean("dnd", false)) dnd(true);
                    paintAll();
                }
                String note = Build.VERSION.SDK_INT >= 34 ? "proses app lain dibatasi Android 14+" : fn + " permintaan proses";
                String message;
                if (mode == 1) message = "RAM • " + note + " • ~" + mb + " MB";
                else if (mode == 2) message = "CACHE IMZYY " + fk + " KB dibersihkan";
                else message = "TURBO ✓ " + note + " • ~" + mb + " MB • " + fk + " KB";
                status(message, OK);
                refresh();
            });
        }).start();
    }

    private void ping() {
        status("📡 Mengetes latency…", WARN);
        new Thread(() -> {
            long best = 9999, tot = 0; int good = 0;
            for (int i = 0; i < 3; i++) {
                try {
                    long t0 = SystemClock.elapsedRealtime();
                    HttpURLConnection conn = (HttpURLConnection) new URL("https://www.google.com/generate_204").openConnection();
                    conn.setConnectTimeout(3000); conn.setReadTimeout(3000); conn.getResponseCode(); conn.disconnect();
                    long d = SystemClock.elapsedRealtime() - t0;
                    best = Math.min(best, d); tot += d; good++;
                } catch (Exception ignored) { }
            }
            final String m = good == 0 ? "✕ Tidak ada internet" : "📡 Ping rata-rata " + (tot / good) + " ms • terbaik " + best + " ms";
            final int col = good == 0 ? BAD : OK;
            ui.post(() -> status(m, col));
        }).start();
    }

    private void dnd(boolean on) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (!nm.isNotificationPolicyAccessGranted()) {
            sp.edit().putBoolean("dnd", false).apply();
            open(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
            status("Izinkan akses DND, lalu tap lagi", WARN); return;
        }
        if (on) {
            sp.edit().putInt("prevf", nm.getCurrentInterruptionFilter()).putBoolean("dnd", true).apply();
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALARMS);
            status("DND aktif (alarm tetap bunyi)", OK);
        } else {
            nm.setInterruptionFilter(sp.getInt("prevf", NotificationManager.INTERRUPTION_FILTER_ALL));
            sp.edit().putBoolean("dnd", false).apply();
            status("DND dikembalikan", MUTE);
        }
    }

    private void bright(boolean on) {
        if (!Settings.System.canWrite(this)) {
            sp.edit().putBoolean("bright", false).apply();
            if (!sp.getBoolean("write_settings_prompted", false)) {
                sp.edit().putBoolean("write_settings_prompted", true).apply();
                openWriteSettings();
            } else status("Izin belum aktif. Aktifkan dari Pengaturan aplikasi.", WARN);
            return;
        }
        ContentResolver cr = getContentResolver();
        try {
            if (on) {
                sp.edit().putInt("pb", Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128))
                        .putInt("pm", Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0)).putBoolean("bright", true).apply();
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0);
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, 255);
                status("Brightness maksimal", OK);
            } else {
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, sp.getInt("pb", 128));
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, sp.getInt("pm", 0));
                sp.edit().putBoolean("bright", false).apply();
                status("Brightness dikembalikan", MUTE);
            }
        } catch (Exception e) { status("Gagal ubah brightness", BAD); }
    }

    private void paintFps() {
        int sel = sp.getInt("fps", -1);
        for (int i = 0; i < fpsBtns.size(); i++) {
            TextView t = fpsBtns.get(i); boolean on = TARGETS[i] == sel;
            t.setTextColor(on ? 0xFF03131C : 0xFFBFF8FF);
            t.setBackground(on ? bg(CY, PU, 11, 0) : bg(0xFF12344B, 0xFF102140, 11, 0x4453E9FF));
        }
    }

    private void preferOnWindows(int hz) {
        try {
            FpsEngine.prefer(bp, this, hz); wm.updateViewLayout(bubble, bp);
            if (panel != null && pp != null) { FpsEngine.prefer(pp, this, hz); wm.updateViewLayout(panel, pp); }
        } catch (Exception ignored) { }
    }

    private void setFps(final int target) {
        final int hz = FpsEngine.pick(this, target);
        if (!FpsEngine.apply(this, hz)) {
            if (!sp.getBoolean("write_settings_prompted", false)) {
                sp.edit().putBoolean("write_settings_prompted", true).apply();
                openWriteSettings();
            }
            status("Izinkan 'Ubah setelan sistem', lalu tap lagi", WARN);
            return;
        }
        sp.edit().putBoolean("write_settings_prompted", false).putInt("fps", target).apply();
        preferOnWindows(hz);
        paintFps(); status("Menerapkan " + hz + " Hz…", WARN);
        ui.postDelayed(() -> { String m = FpsEngine.verify(this, target, hz); status(m, m.startsWith("✓") ? OK : WARN); }, 900);
    }

    private void applyRenderProfile() {
        int profile = sp.getInt("render_profile", 0);
        if (profile == 0) {
            FpsEngine.reset(this);
            status("SYSTEM AUTO: refresh rate dikembalikan", OK);
            return;
        }
        List<Integer> rates = FpsEngine.rates(this);
        if (rates.isEmpty()) { status("Mode refresh rate tidak terbaca", WARN); return; }
        int target = profile == 1 ? rates.get(0) : profile == 2 ? FpsEngine.pick(this, 60) : rates.get(rates.size() - 1);
        if (!FpsEngine.apply(this, target)) {
            status("Butuh izin Ubah setelan sistem. Izinkan lalu tekan APPLY lagi.", WARN);
            openWriteSettings();
            return;
        }
        sp.edit().putInt("fps", target).apply();
        preferOnWindows(target);
        paintFps();
        status("Profil diterapkan • " + target + " Hz", OK);
    }

    private void startGameSession() {
        String pkg = sp.getString("saved_game_package", "");
        if (pkg.isEmpty()) { pageGamePicker(); return; }
        if (thermalBlocked()) return;
        status("Menyiapkan sesi game…", WARN);
        applyRenderProfile();
        boost(0);
        ui.postDelayed(this::launchSavedGame, 1500);
    }

    private void launchSavedGame() {
        String pkg = sp.getString("saved_game_package", "");
        if (pkg.isEmpty()) return;
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch == null) { status("Game tidak ditemukan. Pilih ulang.", WARN); return; }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(launch);
    }

    private void awake(boolean on) { sp.edit().putBoolean("awake", on).apply(); applyAwake(); }

    private void applyAwake() {
        boolean on = sp.getBoolean("awake", false);
        for (WindowManager.LayoutParams p : new WindowManager.LayoutParams[]{bp, pp}) {
            if (p == null) continue;
            if (on) p.flags |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON; else p.flags &= ~WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
        }
        try {
            if (bubble != null && bubble.isAttachedToWindow() && bp != null) wm.updateViewLayout(bubble, bp);
            if (panel != null && pp != null) wm.updateViewLayout(panel, pp);
        } catch (Exception ignored) { }
    }

    private void reflow() {
        if (wm == null) return;
        DisplayMetrics m = getResources().getDisplayMetrics();
        int size = dp(52);
        if (bp != null && bubble != null && bubble.isAttachedToWindow()) {
            boolean right = bp.x + size / 2 >= m.widthPixels / 2;
            bp.x = right ? Math.max(dp(4), m.widthPixels - size - dp(4)) : dp(4);
            bp.y = Math.max(dp(8), Math.min(bp.y, m.heightPixels - size - dp(8)));
            try { wm.updateViewLayout(bubble, bp); } catch (Exception ignored) { }
        }
        if (panel != null && pp != null) {
            int[] sz = panelSize();
            pp.width = sz[0]; pp.height = sz[1];
            pp.x = Math.max(0, Math.min(pp.x, m.widthPixels - sz[0]));
            pp.y = Math.max(0, Math.min(pp.y, m.heightPixels - sz[1]));
            try { wm.updateViewLayout(panel, pp); } catch (Exception ignored) { }
        }
    }

    private long fileSize(File f) {
        if (!f.exists()) return 0;
        if (f.isFile()) return f.length();
        long n = 0; File[] a = f.listFiles();
        if (a != null) for (File x : a) n += fileSize(x);
        return n;
    }

    private void wipe(File f) {
        if (!f.exists()) return;
        if (f.isDirectory()) { File[] a = f.listFiles(); if (a != null) for (File x : a) wipe(x); }
        if (!f.equals(getCacheDir())) f.delete();
    }
}
