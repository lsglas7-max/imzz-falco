package com.imzyyknox.gameturbo;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.animation.ObjectAnimator;
import android.animation.AnimatorSet;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int CY = 0xFF53E9FF, BL = 0xFF3C86FF, PU = 0xFF9270FF, OK = 0xFF55E7A9, WARN = 0xFFFFC857, BAD = 0xFFFF6B6B, MUTE = 0xFF8394A9;
    private static final int[] TARGETS = {10, 30, 60, 90, 0};
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final FpsEngine.Meter meter = new FpsEngine.Meter();
    private final ArrayList<TextView> fpsBtns = new ArrayList<>();
    private final ArrayList<LinearLayout> dashboardCards = new ArrayList<>();
    private SharedPreferences sp;
    private TextView tRam, tSto, tBat, tTemp, tTherm, tHz, liveHz, fpsStatus, boostStatus;
    private SeekBar fpsSlider;
    private TextView sliderValue;
    private final Runnable tick = new Runnable() { public void run() { refresh(); ui.postDelayed(this, 2000); } };

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable bg(int c1, int c2, int r, int stroke) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        g.setCornerRadius(dp(r)); if (stroke != 0) g.setStroke(dp(1), stroke); return g;
    }
    private TextView txt(String s, int sz, int c, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(sz); t.setTextColor(c);
        if (bold) t.setTypeface(Typeface.create("serif", Typeface.BOLD)); else t.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        return t;
    }
    private LinearLayout row() { LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER_VERTICAL); return r; }
    private LinearLayout.LayoutParams mt(int top) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(top); return p; }
    private LinearLayout.LayoutParams w1(boolean first) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1); if (!first) p.leftMargin = dp(8); return p; }
    private LinearLayout card(LinearLayout col, String title, String sub) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(13), dp(10), dp(13), dp(12));
        c.setBackground(bg(0xFF0E1A28, 0xFF080D14, 20, 0x3353E9FF));
        LinearLayout h = row();
        TextView t = txt(title, 13, 0xFFFFFFFF, true); t.setLetterSpacing(.08f);
        TextView s = txt(sub, 8, MUTE, false); s.setLetterSpacing(.12f);
        TextView chevron = txt("⌄", 18, CY, true);
        h.addView(t, new LinearLayout.LayoutParams(0, -2, 1)); h.addView(s);
        chevron.setPadding(dp(8), 0, 0, 0);
        h.addView(chevron);
        c.addView(h);
        c.setTag(Boolean.TRUE);
        h.setOnClickListener(v -> {
            boolean expanded = Boolean.TRUE.equals(c.getTag());
            for (int i = 1; i < c.getChildCount(); i++) c.getChildAt(i).setVisibility(expanded ? View.GONE : View.VISIBLE);
            c.setTag(!expanded);
            chevron.setText(expanded ? "›" : "⌄");
            c.animate().alpha(.96f).setDuration(90).withEndAction(() -> c.animate().alpha(1f).setDuration(120).start()).start();
        });
        dashboardCards.add(c);
        col.addView(c, mt(9)); return c;
    }
    private void showSection(int selected) {
        for (int i = 0; i < dashboardCards.size(); i++) {
            dashboardCards.get(i).setVisibility(i == selected || (selected == 0 && i == 1) ? View.VISIBLE : View.GONE);
        }
        // selected 0 is Home (Turbo + Live Status); other sections are exclusive.
    }

    private TextView tile(LinearLayout r, String label, boolean first) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER); c.setPadding(0, dp(10), 0, dp(10));
        c.setBackground(bg(0xFF0D1723, 0xFF08121C, 14, 0x2253E9FF));
        TextView l = txt(label, 8, MUTE, false); l.setLetterSpacing(.12f);
        TextView v = txt("--", 16, 0xFFFFFFFF, true);
        c.addView(l); c.addView(v); r.addView(c, w1(first)); return v;
    }
    private TextView btn(LinearLayout r, String s, boolean first, Runnable a) {
        TextView t = txt(s, 11, 0xFFBFF8FF, true); t.setGravity(Gravity.CENTER); t.setPadding(dp(4), dp(13), dp(4), dp(13));
        t.setBackground(bg(0xFF12344B, 0xFF102140, 14, 0x4453E9FF)); t.setOnClickListener(v -> { v.animate().scaleX(.96f).scaleY(.96f).setDuration(75).withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(110).start()).start(); a.run(); });
        r.addView(t, w1(first)); return t;
    }

    private void addSmartToggle(LinearLayout parent, String key, String title, String desc) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setPadding(dp(12), dp(10), dp(12), dp(10));
        item.setBackground(bg(0xFF0B1521, 0xFF0A1019, 14, 0x223FBCD4));
        LinearLayout line = row();
        TextView name = txt(title, 10, 0xFFEAF5FF, true);
        Switch sw = new Switch(this);
        sw.setChecked(sp.getBoolean(key, false));
        sw.setOnCheckedChangeListener((button, checked) -> {
            if ("frame_opt".equals(key)) {
                sp.edit().putBoolean(key, checked).apply();
                if (checked) setFps(0); else { FpsEngine.reset(MainActivity.this); paintFps(); fpsStatus("Frame optimization dimatikan; layar kembali otomatis", MUTE, false); }
            } else if ("battery_profile".equals(key)) {
                if (!ProfileEngine.batteryBalance(MainActivity.this, checked)) {
                    sw.setOnCheckedChangeListener(null); sw.setChecked(!checked);
                    sw.setOnCheckedChangeListener((b, on) -> { if (ProfileEngine.batteryBalance(MainActivity.this, on)) sp.edit().putBoolean(key, on).apply(); });
                    startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName())));
                    Toast.makeText(MainActivity.this, "Izinkan Ubah setelan sistem, lalu aktifkan lagi.", Toast.LENGTH_LONG).show(); return;
                }
                sp.edit().putBoolean(key, checked).apply();
                Toast.makeText(MainActivity.this, checked ? "Battery Balance aktif: brightness dan refresh rate diturunkan." : "Pengaturan layar dipulihkan.", Toast.LENGTH_LONG).show();
            } else if ("touch_profile".equals(key)) {
                sp.edit().putBoolean(key, checked).apply();
                startActivity(new Intent(Settings.ACTION_DISPLAY_SETTINGS));
                Toast.makeText(MainActivity.this, "Atur Touch sensitivity dari pengaturan layar jika tersedia.", Toast.LENGTH_LONG).show();
            } else sp.edit().putBoolean(key, checked).apply();
        });
        line.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
        line.addView(sw);
        item.addView(line);
        TextView description = txt(desc, 9, MUTE, false);
        description.setLineSpacing(0, 1.15f);
        item.addView(description, mt(4));
        parent.addView(item, mt(8));
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("turbo", MODE_PRIVATE);
        final int bgc = Color.rgb(5, 8, 13);
        GradientDrawable galaxy = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF101A35, 0xFF080D1B, 0xFF170F2B, 0xFF050810});
        getWindow().setStatusBarColor(bgc); getWindow().setNavigationBarColor(bgc);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED && !sp.getBoolean("notification_prompted", false)) {
            sp.edit().putBoolean("notification_prompted", true).apply();
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }

        ScrollView sv = new ScrollView(this);
        sv.setBackground(galaxy); sv.setFillViewport(true);
        sv.setOnApplyWindowInsetsListener((v, in) -> {
            v.setPadding(in.getSystemWindowInsetLeft(), in.getSystemWindowInsetTop(), in.getSystemWindowInsetRight(), in.getSystemWindowInsetBottom());
            return in;
        });
        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setPadding(dp(14), dp(14), dp(14), dp(24));
        sv.addView(col);

        // Header
        LinearLayout head = row();
        TextView logo = txt("IK", 16, CY, true); logo.setGravity(Gravity.CENTER); logo.setBackground(bg(0xFF102A40, 0xFF07101A, 14, 0x6648DFFF));
        head.addView(logo, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout ti = new LinearLayout(this); ti.setOrientation(LinearLayout.VERTICAL); ti.setPadding(dp(12), 0, 0, 0);
        TextView n1 = txt("IMZYY KNOX", 17, 0xFFFFFFFF, true); n1.setLetterSpacing(.14f);
        TextView n2 = txt("GAME TURBO BY IMZYYKNOX • v7.0", 8, 0xFF9CAED0, false); n2.setLetterSpacing(.16f);
        ti.addView(n1); ti.addView(n2); head.addView(ti);
        col.addView(head);

        // Hero
        LinearLayout hero = card(col, "TURBO BOOST", "RAM • CACHE");
        TextView ring = txt("TURBO", 18, 0xFF03131C, true); ring.setGravity(Gravity.CENTER); ring.setLetterSpacing(.1f);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{CY, BL, PU}); g.setShape(GradientDrawable.OVAL); g.setStroke(dp(3), 0x55FFFFFF);
        ring.setBackground(g); ring.setOnClickListener(v -> boost(0));
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(dp(112), dp(112)); rlp.gravity = Gravity.CENTER_HORIZONTAL; rlp.topMargin = dp(14);
        hero.addView(ring, rlp);
        boostStatus = txt("Tap TURBO untuk bersihkan RAM & cache", 10, MUTE, false); boostStatus.setGravity(Gravity.CENTER);
        hero.addView(boostStatus, mt(14));

        // Live stats
        LinearLayout st = card(col, "LIVE STATUS", "REAL DATA");
        LinearLayout s1 = row(); tRam = tile(s1, "RAM USED", true); tSto = tile(s1, "STORAGE", false); tBat = tile(s1, "BATTERY", false); st.addView(s1, mt(12));
        LinearLayout s2 = row(); tTemp = tile(s2, "TEMP", true); tTherm = tile(s2, "THERMAL", false); tHz = tile(s2, "DISPLAY", false); st.addView(s2, mt(8));

        // FPS
        LinearLayout fc = card(col, "FPS CONTROL", "REFRESH RATE");
        List<Integer> rates = FpsEngine.rates(this);
        StringBuilder rs = new StringBuilder();
        for (int r : rates) rs.append(rs.length() == 0 ? "" : " • ").append(r).append(" Hz");
        fc.addView(txt("Layar mendukung: " + rs, 11, 0xFFBFD3E6, false), mt(10));
        LinearLayout live = row();
        TextView ll = txt("LIVE", 9, MUTE, true); ll.setLetterSpacing(.2f);
        liveHz = txt("-- Hz", 26, CY, true);
        live.addView(ll); live.addView(liveHz); liveHz.setPadding(dp(12), 0, 0, 0);
        fc.addView(live, mt(8));
        LinearLayout fr = row();
        for (int i = 0; i < TARGETS.length; i++) {
            final int tg = TARGETS[i];
            fpsBtns.add(btn(fr, tg == 0 ? "MAX" : String.valueOf(tg), i == 0, () -> setFps(tg)));
        }
        fc.addView(fr, mt(10));
        TextView sliderTitle = txt("PRECISION FRAME TARGET", 9, MUTE, true);
        sliderTitle.setLetterSpacing(.16f);
        fc.addView(sliderTitle, mt(16));
        sliderValue = txt("90 Hz", 22, CY, true);
        fc.addView(sliderValue, mt(4));
        fpsSlider = new SeekBar(this);
        fpsSlider.setMax(110);
        fpsSlider.setProgress(80);
        fpsSlider.setProgressTintList(android.content.res.ColorStateList.valueOf(CY));
        fpsSlider.setThumbTintList(android.content.res.ColorStateList.valueOf(PU));
        fc.addView(fpsSlider, mt(2));
        TextView sliderHint = txt("Geser untuk memilih target. Nilai akan disesuaikan dengan mode refresh rate yang benar-benar didukung layar.", 9, MUTE, false);
        fc.addView(sliderHint, mt(2));
        fpsSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) {
                int requested = 10 + p;
                int actual = FpsEngine.pick(MainActivity.this, requested);
                sliderValue.setText(actual + " Hz" + (actual != requested ? " • mode terdekat" : ""));
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {
                int requested = 10 + b.getProgress();
                setFps(requested >= 115 ? 0 : requested);
            }
        });
        fpsStatus = txt("Pilih target FPS. MAX = refresh rate tertinggi yang didukung layar.", 10, MUTE, false);
        fc.addView(fpsStatus, mt(10));
        LinearLayout fa = row();
        btn(fa, "RESET AUTO", true, () -> { FpsEngine.reset(this); paintFps(); fpsStatus("Dikembalikan ke otomatis", MUTE, false); });
        btn(fa, "MOTION SETTINGS", false, () -> startActivity(new Intent(Settings.ACTION_DISPLAY_SETTINGS)));
        fc.addView(fa, mt(10));
        fc.addView(txt("Catatan: ini mengunci laju layar (nyata). Aplikasi tidak bisa memaksa FPS di dalam game lain tanpa root.", 9, 0xFF52667A, false), mt(10));

        // Advanced controls: clearly distinguish supported device controls from game-engine overrides.
        LinearLayout adv = card(col, "ADVANCED PERFORMANCE", "SMART PROFILES");
        TextView renderLabel = txt("RENDER PROFILE", 9, MUTE, true); renderLabel.setLetterSpacing(.16f);
        adv.addView(renderLabel, mt(12));
        Spinner render = new Spinner(this);
        String[] renderModes = {"SYSTEM AUTO", "COMPATIBILITY • LOW DISPLAY RATE", "BALANCED • 60 Hz TARGET", "PERFORMANCE • MAX DISPLAY RATE"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, renderModes);
        render.setAdapter(adapter);
        render.setSelection(sp.getInt("render_profile", 0));
        render.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(android.widget.AdapterView<?> p) {}
            public void onItemSelected(android.widget.AdapterView<?> p, android.view.View v, int pos, long id) { sp.edit().putInt("render_profile", pos).apply(); }
        });
        adv.addView(render, mt(6));
        btn(adv, "APPLY DISPLAY PROFILE", true, this::applyRenderProfile);
        adv.addView(txt("Profil ini menerapkan refresh rate layar yang didukung. Ini bukan pengganti renderer Vulkan/OpenGL atau pengaturan grafis internal game. Perlu izin Ubah setelan sistem.", 9, MUTE, false), mt(6));
        addSmartToggle(adv, "frame_opt", "FRAME RATE OPTIMIZATION", "Memilih refresh rate layar yang tersedia dan memantau kestabilannya.");
        addSmartToggle(adv, "thermal_guard", "THERMAL GUARD", "Mode adaptif: waspada mulai 42°C dan tahan boost pada 44°C (sensor suhu baterai). Tidak mendinginkan chipset secara aktif.");
        addSmartToggle(adv, "battery_profile", "BATTERY BALANCE", "Preferensi profil hemat daya untuk sesi bermain lebih lama.");
        addSmartToggle(adv, "touch_profile", "TOUCH RESPONSE PROFILE", "Simpan preferensi respons sentuhan; tidak mengubah sampling rate hardware.");
        LinearLayout gameActions = row();
        btn(gameActions, "CHOOSE GAME", true, this::chooseGame);
        btn(gameActions, "AUTO START SESSION", false, this::startGameSession);
        adv.addView(gameActions, mt(8));
        adv.addView(txt("Otomatis menerapkan profil layar dan boost yang diizinkan sebelum membuka game. Pembersihan cache dibatasi ke cache aplikasi ini oleh Android.", 9, MUTE, false), mt(5));

        // Graphics profiles: real, user-controlled presets and guidance, not fake GPU overrides.
        LinearLayout gc = card(col, "GRAPHICS EXPERIENCE", "VISUAL QUALITY • DEVICE SAFE");
        gc.addView(txt("Pilih sasaran visual untuk sesi game. Profil menyimpan rekomendasi dan mengatur refresh rate layar bila didukung; kualitas tekstur, shader, resolusi internal, dan renderer tetap dikendalikan game.", 9, MUTE, false), mt(8));
        Spinner graphics = new Spinner(this);
        String[] graphicsModes = {"SMART AUTO • ADAPTIVE", "ULTRA CLARITY • VISUAL FIRST", "BALANCED • SMOOTH + CLEAR", "PERFORMANCE • LOW LOAD", "THERMAL SAFE • COOLER SESSION"};
        graphics.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, graphicsModes));
        graphics.setSelection(sp.getInt("graphics_profile", 0));
        graphics.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(android.widget.AdapterView<?> p) {}
            public void onItemSelected(android.widget.AdapterView<?> p, android.view.View v, int pos, long id) { sp.edit().putInt("graphics_profile", pos).apply(); }
        });
        gc.addView(graphics, mt(6));
        TextView graphicInfo = txt("SMART AUTO: sesuaikan profil dengan kondisi perangkat.", 9, CY, false);
        gc.addView(graphicInfo, mt(8));
        btn(gc, "APPLY GRAPHIC PROFILE", true, () -> {
            int mode = sp.getInt("graphics_profile", 0);
            String[] notes = {"SMART AUTO: refresh rate dipilih berdasarkan kondisi thermal.", "ULTRA CLARITY: refresh rate layar dimaksimalkan; naikkan texture/resolution dari menu game.", "BALANCED: target layar sekitar 60 Hz untuk keseimbangan.", "PERFORMANCE: mode refresh tertinggi yang didukung layar.", "THERMAL SAFE: mode refresh terendah untuk mengurangi beban layar."};
            graphicInfo.setText(notes[Math.max(0, Math.min(mode, notes.length - 1))]);
            String result = ProfileEngine.applyGraphics(this, mode);
            graphicInfo.setText(graphicInfo.getText() + "\n" + result);
            graphicInfo.setTextColor(result.startsWith("Refresh") ? OK : WARN);
            if (result.startsWith("Izin")) startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName())));
            Toast.makeText(this, result, Toast.LENGTH_LONG).show();
        });
        LinearLayout gr = row();
        btn(gr, "GAME GRAPHICS SETTINGS", true, () -> {
            try { startActivity(new Intent("android.settings.GAME_SETTINGS")); }
            catch (Exception e) { startActivity(new Intent(Settings.ACTION_DISPLAY_SETTINGS)); }
        });
        btn(gr, "DISPLAY SETTINGS", false, () -> startActivity(new Intent(Settings.ACTION_DISPLAY_SETTINGS)));
        gc.addView(gr, mt(8));

        // Actions
        LinearLayout ac = card(col, "TOOLS", "QUICK ACTIONS");
        LinearLayout a1 = row();
        btn(a1, "FLOATING HUB", true, this::startHub);
        btn(a1, "CLEAN RAM", false, () -> boost(1));
        ac.addView(a1, mt(12));
        LinearLayout a2 = row();
        btn(a2, "CLEAR CACHE", true, () -> boost(2));
        btn(a2, "BATTERY", false, () -> startActivity(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)));
        ac.addView(a2, mt(8));
        LinearLayout a3 = row();
        btn(a3, "VOICE STUDIO", true, () -> startActivity(new Intent(this, VoiceStudioActivity.class)));
        btn(a3, "APP PERMISSIONS", false, () -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))));
        ac.addView(a3, mt(8));
        LinearLayout a4 = row();
        btn(a4, "CACHE CONTROL CENTER", true, () -> startActivity(new Intent(this, CacheControlActivity.class)));
        btn(a4, "SYSTEM STORAGE", false, () -> { try { startActivity(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)); } catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); } });
        ac.addView(a4, mt(8));

        // Device
        LinearLayout dc = card(col, "DEVICE", "SCANNER");
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        String soc = Build.VERSION.SDK_INT >= 31 ? Build.SOC_MODEL : Build.HARDWARE;
        String info = "Model      " + Build.MANUFACTURER + " " + Build.MODEL + "\nAndroid    " + Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")\nChipset    " + soc
                + "\nCPU        " + Runtime.getRuntime().availableProcessors() + " cores • " + Build.SUPPORTED_ABIS[0]
                + "\nRAM        " + (Boost.mem(this).totalMem >> 20) + " MB\nLayar      " + dm.widthPixels + "×" + dm.heightPixels + " • " + dm.densityDpi + " dpi\nKernel     " + System.getProperty("os.version");
        TextView it = txt(info, 11, 0xFFBFD3E6, false); it.setTypeface(Typeface.MONOSPACE); it.setLineSpacing(0, 1.25f);
        dc.addView(it, mt(12));

        TextView foot = txt("Developed by IMZYY KNOX", 9, 0xFF52667A, false); foot.setGravity(Gravity.CENTER); foot.setLetterSpacing(.15f);
        col.addView(foot, mt(20));

        setContentView(sv);
        // Single-section navigation keeps the portrait home screen short and organized.
        LinearLayout nav = row();
        nav.setPadding(0, dp(10), 0, dp(5));
        String[] navNames = {"HOME", "FPS", "BOOST", "GRAPHICS", "TOOLS", "DEVICE"};
        int[] navCards = {0, 2, 3, 4, 5, 6};
        for (int ni = 0; ni < navNames.length; ni++) {
            final int target = navCards[ni];
            TextView tab = txt(navNames[ni], 8, 0xFFBFEAFF, true);
            tab.setGravity(Gravity.CENTER);
            tab.setPadding(dp(9), dp(11), dp(9), dp(11));
            tab.setBackground(bg(0xFF18284A, 0xFF10182D, 12, 0x554D9DFF));
            LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(0, -2, 1);
            if (ni > 0) nlp.leftMargin = dp(4);
            nav.addView(tab, nlp);
            tab.setOnClickListener(v -> {
                showSection(target);
                for (int k = 0; k < nav.getChildCount(); k++) {
                    TextView navTab = (TextView) nav.getChildAt(k);
                    navTab.setBackground(bg(navTab == tab ? 0xFF3C86FF : 0xFF18284A,
                            navTab == tab ? 0xFF9270FF : 0xFF10182D, 12, 0x554D9DFF));
                    navTab.setTextColor(navTab == tab ? 0xFFFFFFFF : 0xFFBFEAFF);
                }
            });
        }
        col.addView(nav, 1);
        showSection(0);
        // Staggered entrance and subtle hero breathing animation.
        for (int i = 0; i < col.getChildCount(); i++) {
            View child = col.getChildAt(i);
            child.setAlpha(0f); child.setTranslationY(dp(14));
            child.animate().alpha(1f).translationY(0f).setStartDelay(i * 45L).setDuration(360).start();
        }
        ObjectAnimator pulseX = ObjectAnimator.ofFloat(ring, "scaleX", 1f, 1.045f, 1f);
        ObjectAnimator pulseY = ObjectAnimator.ofFloat(ring, "scaleY", 1f, 1.045f, 1f);
        AnimatorSet pulse = new AnimatorSet(); pulse.playTogether(pulseX, pulseY); pulse.setDuration(1900); pulse.setStartDelay(450); pulse.start();
        paintFps();
    }

    @Override protected void onResume() { super.onResume(); meter.start(liveHz); ui.post(tick); }
    @Override protected void onPause() { super.onPause(); meter.stop(); ui.removeCallbacks(tick); }

    private void fpsStatus(String s, int c, boolean unused) { fpsStatus.setText(s); fpsStatus.setTextColor(c); }
    private void paintFps() {
        int sel = sp.getInt("fps", -1);
        for (int i = 0; i < fpsBtns.size(); i++) {
            TextView t = fpsBtns.get(i); boolean on = TARGETS[i] == sel;
            t.setTextColor(on ? 0xFF03131C : 0xFFBFF8FF);
            t.setBackground(on ? bg(CY, PU, 14, 0) : bg(0xFF12344B, 0xFF102140, 14, 0x4453E9FF));
        }
    }
    private void applyRenderProfile() {
        int profile = sp.getInt("render_profile", 0);
        if (profile == 0) {
            FpsEngine.reset(this);
            paintFps();
            fpsStatus("Profil SYSTEM AUTO diterapkan", OK, false);
            return;
        }
        List<Integer> rates = FpsEngine.rates(this);
        if (rates.isEmpty()) { fpsStatus("Mode refresh rate tidak terbaca", WARN, false); return; }
        int target;
        if (profile == 1) target = rates.get(0);
        else if (profile == 2) target = FpsEngine.pick(this, 60);
        else target = rates.get(rates.size() - 1);
        if (!FpsEngine.apply(this, target)) {
            fpsStatus("Izinkan 'Ubah setelan sistem', lalu tekan APPLY lagi", WARN, false);
            startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName())));
            return;
        }
        sp.edit().putInt("fps", target).apply();
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        FpsEngine.prefer(lp, this, target); getWindow().setAttributes(lp);
        paintFps();
        fpsStatus("Profil diterapkan: layar " + target + " Hz", OK, false);
    }

    private void setFps(final int target) {
        final int hz = FpsEngine.pick(this, target);
        if (!FpsEngine.apply(this, hz)) {
            fpsStatus("Izinkan 'Ubah setelan sistem', lalu tap lagi", WARN, false);
            if (!sp.getBoolean("write_settings_prompted", false)) {
                sp.edit().putBoolean("write_settings_prompted", true).apply();
                startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName())));
            } else fpsStatus("Izin belum aktif. Aktifkan sekali dari Pengaturan aplikasi.", WARN, false);
            return;
        }
        sp.edit().putBoolean("write_settings_prompted", false).putInt("fps", target).apply();
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        FpsEngine.prefer(lp, this, hz); getWindow().setAttributes(lp);
        paintFps(); fpsStatus("Menerapkan " + hz + " Hz…", WARN, false);
        ui.postDelayed(() -> { String m = FpsEngine.verify(this, target, hz); fpsStatus(m, m.startsWith("Layar berjalan") ? OK : WARN, false); }, 900);
    }
    private void boost(final int mode) {
        if (sp.getBoolean("thermal_guard", false)) {
            Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            float temp = battery == null ? 0 : battery.getIntExtra("temperature", 0) / 10f;
            if (temp >= 44f) { boostStatus.setText("THERMAL GUARD: boost dihentikan pada " + temp + "°C. Istirahatkan perangkat dan biarkan suhu turun."); boostStatus.setTextColor(WARN); return; }
            if (temp >= 42f) { boostStatus.setText("THERMAL GUARD: suhu " + temp + "°C. Mode hati-hati aktif; hindari sesi berat."); boostStatus.setTextColor(WARN); }
        }
        boostStatus.setText("Boosting…"); boostStatus.setTextColor(WARN);
        new Thread(() -> { final String m = Boost.run(this, mode); ui.post(() -> { boostStatus.setText(m); boostStatus.setTextColor(OK); refresh(); }); }).start();
    }
    private void startHub() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan 'Tampil di atas aplikasi lain', lalu tap lagi", Toast.LENGTH_LONG).show();
            if (!sp.getBoolean("overlay_prompted", false)) {
                sp.edit().putBoolean("overlay_prompted", true).apply();
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            } else Toast.makeText(this, "Izin overlay belum aktif. Aktifkan dari Pengaturan aplikasi.", Toast.LENGTH_LONG).show();
        } else {
            sp.edit().putBoolean("overlay_prompted", false).apply();
            startForegroundService(new Intent(this, FloatingService.class));
            Toast.makeText(this, "Hub aktif. Tap bubble logo", Toast.LENGTH_LONG).show();
            moveTaskToBack(true);
        }
    }
    private void chooseGame() {
        android.content.pm.PackageManager pm = getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER);
        java.util.List<android.content.pm.ResolveInfo> apps = pm.queryIntentActivities(query, 0);
        java.util.Collections.sort(apps, (a,b) -> String.CASE_INSENSITIVE_ORDER.compare(a.loadLabel(pm).toString(), b.loadLabel(pm).toString()));
        java.util.ArrayList<String> labels = new java.util.ArrayList<>(), packages = new java.util.ArrayList<>();
        for (android.content.pm.ResolveInfo ri : apps) { String pkg = ri.activityInfo.packageName; if (!pkg.equals(getPackageName()) && !packages.contains(pkg)) { labels.add(ri.loadLabel(pm).toString()); packages.add(pkg); } }
        if (labels.isEmpty()) { Toast.makeText(this, "Tidak ada aplikasi yang bisa dipilih.", Toast.LENGTH_SHORT).show(); return; }
        new android.app.AlertDialog.Builder(this).setTitle("Pilih game/aplikasi").setItems(labels.toArray(new String[0]), (d, which) -> {
            sp.edit().putString("saved_game_package", packages.get(which)).putString("saved_game_name", labels.get(which)).apply();
            Toast.makeText(this, "Tersimpan: " + labels.get(which), Toast.LENGTH_SHORT).show();
        }).setNegativeButton("BATAL", null).show();
    }
    private void startGameSession() {
        String pkg = sp.getString("saved_game_package", "");
        if (pkg.isEmpty()) { chooseGame(); return; }
        if (sp.getBoolean("thermal_guard", false)) {
            Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            float temp = battery == null ? 0 : battery.getIntExtra("temperature", 0) / 10f;
            if (temp >= 44f) { Toast.makeText(this, "AUTO START ditahan Thermal Guard: " + temp + "°C", Toast.LENGTH_LONG).show(); return; }
            if (temp >= 42f) { Toast.makeText(this, "Thermal Guard: suhu tinggi " + temp + "°C. Turunkan beban sebelum bermain.", Toast.LENGTH_LONG).show(); }
        }
        applyRenderProfile();
        boost(0);
        Toast.makeText(this, "Menyiapkan sesi game…", Toast.LENGTH_SHORT).show();
        ui.postDelayed(this::launchSavedGame, 1500);
    }

    private void launchSavedGame() {
        String pkg = sp.getString("saved_game_package", ""); if (pkg.isEmpty()) { chooseGame(); return; }
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch == null) { Toast.makeText(this, "Game tidak ditemukan. Pilih ulang.", Toast.LENGTH_LONG).show(); return; }
        startActivity(launch);
    }

    private void refresh() {
        android.app.ActivityManager.MemoryInfo mi = Boost.mem(this);
        int used = (int) (100 - mi.availMem * 100 / Math.max(1, mi.totalMem));
        tRam.setText(used + "%"); tRam.setTextColor(used > 85 ? BAD : used > 70 ? WARN : OK);
        android.os.StatFs sf = new android.os.StatFs(Environment.getDataDirectory().getPath());
        tSto.setText((sf.getAvailableBytes() >> 30) + " GB");
        Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (b != null) {
            float t = b.getIntExtra("temperature", 0) / 10f;
            tBat.setText(b.getIntExtra("level", 0) * 100 / Math.max(1, b.getIntExtra("scale", 100)) + "%");
            tTemp.setText(t + "°"); tTemp.setTextColor(t >= 42 ? BAD : t >= 38 ? WARN : OK);
        }
        if (Build.VERSION.SDK_INT >= 29) {
            int ts = ((PowerManager) getSystemService(POWER_SERVICE)).getCurrentThermalStatus();
            tTherm.setText(ts <= 0 ? "COOL" : ts == 1 ? "WARM" : ts == 2 ? "WARM+" : ts == 3 ? "HOT" : "CRIT");
            tTherm.setTextColor(ts <= 0 ? OK : ts <= 2 ? WARN : BAD);
        } else tTherm.setText("N/A");
        tHz.setText(Math.round(FpsEngine.current(this)) + " Hz");
    }
}
