package com.imzyyknox.gameturbo;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayDeque;
import java.util.Locale;

/**
 * Otomatisasi resmi lewat Accessibility: membuka Info Aplikasi, lalu menekan tombol
 * "Clear cache" / "Force stop" seperti yang dilakukan pengguna. Hanya jalan jika pengguna
 * mengaktifkan layanan ini sendiri di Pengaturan Aksesibilitas.
 */
public class CleanerService extends AccessibilityService {
    interface Listener { void on(String msg, boolean ok, boolean queueDone); }

    static final int CLEAR_CACHE = 1, FORCE_STOP = 2;
    static Listener listener;
    private static CleanerService inst;

    private static final String[] CLEAR = {"clear cache", "hapus cache", "bersihkan cache", "kosongkan cache", "hapus tembolok", "hapus cache"};
    private static final String[] STORAGE = {"storage", "penyimpanan"};
    private static final String[] STORAGE_EXCL = {"clear", "hapus", "manage", "kelola", "data", "kosongkan", "bersihkan"};
    private static final String[] FORCE = {"force stop", "paksa berhenti", "paksa hentikan", "hentikan paksa", "force-stop"};
    private static final String[] CONFIRM_OK = {"ok", "oke", "yes", "ya"};

    private static class Task {
        final String pkg, label; final int type;
        Task(String p, String l, int t) { pkg = p; label = l; type = t; }
    }

    private final ArrayDeque<Task> queue = new ArrayDeque<>();
    private final Handler h = new Handler(Looper.getMainLooper());
    private Task cur;
    private boolean busy;
    private int phase, depth;
    private long startedAt, phaseAt;
    private int totalCount, doneCount;
    private FrameLayout curtain;
    private TextView curtainTitle, curtainSub, curtainPct;
    private View curtainFill, curtainRest;

    static boolean enabled() { return inst != null; }
    static int pending() { return inst == null ? 0 : inst.queue.size() + (inst.cur != null ? 1 : 0); }
    static void enqueue(String pkg, int type, String label) {
        if (inst == null) return;
        if (!inst.busy && inst.cur == null) { inst.totalCount = 0; inst.doneCount = 0; }
        inst.totalCount++;
        inst.queue.add(new Task(pkg, label == null ? pkg : label, type));
        if (!inst.busy) inst.next();
    }

    @Override protected void onServiceConnected() { super.onServiceConnected(); inst = this; }
    @Override public boolean onUnbind(Intent intent) { inst = null; hideCurtain(); return super.onUnbind(intent); }
    @Override public void onDestroy() { inst = null; h.removeCallbacksAndMessages(null); hideCurtain(); super.onDestroy(); }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }

    private void say(String m, boolean ok, boolean done) { if (listener != null) listener.on(m, ok, done); }

    private void next() {
        cur = queue.poll();
        if (cur == null) { busy = false; hideCurtain(); return; }
        busy = true;
        showCurtain();
        updateCurtain(); phase = 0; depth = 1; startedAt = SystemClock.elapsedRealtime(); phaseAt = startedAt;
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + cur.pkg));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(i);
        } catch (Exception e) { finish("Gagal membuka Info Aplikasi: " + cur.label, false); return; }
        h.removeCallbacks(poll);
        h.postDelayed(poll, 650);
    }

    private final Runnable poll = new Runnable() {
        @Override public void run() {
            if (cur == null) return;
            if (SystemClock.elapsedRealtime() - startedAt > 14000) { finish("Waktu habis: " + cur.label + " (tombol tidak ditemukan)", false); return; }
            try { step(); } catch (Exception e) { finish("Gagal: " + cur.label, false); return; }
            if (cur != null) h.postDelayed(this, 300);
        }
    };

    private void step() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        CharSequence pk = root.getPackageName();
        boolean inSettings = pk != null && pk.toString().toLowerCase(Locale.ROOT).contains("settings");
        boolean confirmPhase = cur.type == FORCE_STOP && phase == 1;
        if (!inSettings && !confirmPhase) return;
        if (cur.type == FORCE_STOP) stepForceStop(root); else stepClear(root);
    }

    private void stepForceStop(AccessibilityNodeInfo root) {
        if (phase == 0) {
            AccessibilityNodeInfo n = findClickable(root, FORCE, false, null);
            if (n == null) return;
            if (!n.isEnabled()) { finish("Tidak berjalan: " + cur.label, true); return; }
            n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            phase = 1; phaseAt = SystemClock.elapsedRealtime();
            return;
        }
        if (SystemClock.elapsedRealtime() - phaseAt < 700) return;
        AccessibilityNodeInfo ok = findClickable(root, CONFIRM_OK, true, null);
        if (ok == null) ok = findClickable(root, FORCE, false, null);
        if (ok == null) return;
        ok.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        finish("Force stop: " + cur.label, true);
    }

    private void stepClear(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo n = findClickable(root, CLEAR, false, null);
        if (n != null) {
            if (!n.isEnabled()) { finish("Tidak ada cache: " + cur.label, true); return; }
            n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            finish("Cache dibersihkan: " + cur.label, true);
            return;
        }
        if (phase == 0) {
            AccessibilityNodeInfo s = findClickable(root, STORAGE, false, STORAGE_EXCL);
            if (s != null) {
                s.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                phase = 1; depth = 2; phaseAt = SystemClock.elapsedRealtime();
            } else {
                scrollAny(root);
            }
        }
    }

    private void scrollAny(AccessibilityNodeInfo n) {
        if (n == null) return;
        if (n.isScrollable() && n.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) return;
        for (int i = 0; i < n.getChildCount(); i++) scrollAny(n.getChild(i));
    }

    private void finish(String msg, boolean ok) {
        final int backs = cur != null && cur.type == CLEAR_CACHE ? depth : 1;
        cur = null;
        doneCount++;
        updateCurtain();
        h.removeCallbacks(poll);
        for (int k = 1; k <= backs; k++) h.postDelayed(() -> performGlobalAction(GLOBAL_ACTION_BACK), 450L * k);
        final boolean last = queue.isEmpty();
        final String text = msg; final boolean good = ok;
        h.postDelayed(() -> {
            say(text, good, last);
            next();
        }, 450L * backs + 500L);
    }


    // ---------------------------------------------------------------- tirai pembersih
    private static int dp(Context c, int v) { return (int) (v * c.getResources().getDisplayMetrics().density + .5f); }

    private TextView ctext(String t, int sz, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t); v.setTextSize(sz); v.setTextColor(color); v.setGravity(Gravity.CENTER);
        v.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        return v;
    }

    /** Tirai hitam menutupi layar Info Aplikasi selama otomatisasi, jadi terasa seperti satu tombol Clear saja. */
    private void showCurtain() {
        if (curtain != null) return;
        try {
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            FrameLayout f = new FrameLayout(this);
            f.setBackgroundColor(0xFF050506);
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL); col.setGravity(Gravity.CENTER);
            col.setPadding(dp(this, 28), 0, dp(this, 28), 0);
            IconView logo = new IconView(this).set(IconView.CACHE, 0xFFFFFFFF, true);
            col.addView(logo, new LinearLayout.LayoutParams(dp(this, 56), dp(this, 56)));
            curtainTitle = ctext("MEMBERSIHKAN CACHE", 15, 0xFFFFFFFF, true); curtainTitle.setLetterSpacing(.16f);
            col.addView(curtainTitle, lpTop(18));
            curtainSub = ctext("Menyiapkan…", 11, 0xFF8B8B93, false);
            col.addView(curtainSub, lpTop(6));
            LinearLayout bar = new LinearLayout(this);
            GradientDrawable track = new GradientDrawable(); track.setColor(0xFF202024); track.setCornerRadius(dp(this, 3));
            bar.setBackground(track);
            curtainFill = new View(this);
            GradientDrawable fg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xFFFFFFFF, 0xFF86868E});
            fg.setCornerRadius(dp(this, 3)); curtainFill.setBackground(fg);
            curtainRest = new View(this);
            bar.addView(curtainFill, new LinearLayout.LayoutParams(0, dp(this, 6), 1));
            bar.addView(curtainRest, new LinearLayout.LayoutParams(0, dp(this, 6), 99));
            LinearLayout.LayoutParams blp = lpTop(22); blp.width = dp(this, 220);
            col.addView(bar, blp);
            curtainPct = ctext("0%", 11, 0xFFC9C9CF, true);
            col.addView(curtainPct, lpTop(8));
            TextView cancel = ctext("BATAL", 11, 0xFFEDEDF0, true);
            cancel.setLetterSpacing(.14f);
            cancel.setPadding(dp(this, 26), dp(this, 11), dp(this, 26), dp(this, 11));
            GradientDrawable cb = new GradientDrawable(); cb.setColor(0xFF1A1A1D); cb.setCornerRadius(dp(this, 14)); cb.setStroke(dp(this, 1), 0x44FFFFFF);
            cancel.setBackground(cb);
            cancel.setOnClickListener(v -> cancelAll());
            col.addView(cancel, lpTop(26));
            f.addView(col, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));
            WindowManager.LayoutParams p = new WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.OPAQUE);
            p.gravity = Gravity.TOP | Gravity.START;
            if (android.os.Build.VERSION.SDK_INT >= 28) p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            wm.addView(f, p);
            curtain = f;
        } catch (Exception e) { curtain = null; }
    }

    private LinearLayout.LayoutParams lpTop(int dpTop) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.topMargin = dp(this, dpTop); p.gravity = Gravity.CENTER_HORIZONTAL;
        return p;
    }

    private void updateCurtain() {
        if (curtain == null || curtainFill == null) return;
        int total = Math.max(1, totalCount);
        int done = Math.min(doneCount, total);
        int pct = done * 100 / total;
        ((LinearLayout.LayoutParams) curtainFill.getLayoutParams()).weight = Math.max(1, pct);
        ((LinearLayout.LayoutParams) curtainRest.getLayoutParams()).weight = Math.max(1, 100 - pct);
        curtainFill.requestLayout();
        curtainPct.setText(pct + "%  •  " + done + "/" + total);
        curtainTitle.setText(cur != null && cur.type == FORCE_STOP ? "MENGHENTIKAN APLIKASI" : "MEMBERSIHKAN CACHE");
        curtainSub.setText(cur == null ? "Selesai" : cur.label);
    }

    private void hideCurtain() {
        if (curtain == null) return;
        try { ((WindowManager) getSystemService(WINDOW_SERVICE)).removeView(curtain); } catch (Exception ignored) { }
        curtain = null; curtainTitle = curtainSub = curtainPct = null; curtainFill = curtainRest = null;
    }

    private void cancelAll() {
        queue.clear(); cur = null; busy = false;
        h.removeCallbacksAndMessages(null);
        hideCurtain();
        performGlobalAction(GLOBAL_ACTION_BACK);
        say("Pembersihan dibatalkan", false, true);
    }

    private static boolean matches(String raw, String[] keys, boolean exact, String[] excl) {
        if (raw == null) return false;
        String s = raw.toLowerCase(Locale.ROOT).trim();
        if (s.isEmpty() || s.length() > 60) return false;
        if (excl != null) for (String x : excl) if (s.contains(x)) return false;
        for (String k : keys) { if (exact ? s.equals(k) : s.contains(k)) return true; }
        return false;
    }

    private AccessibilityNodeInfo clickableUp(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo x = n;
        for (int i = 0; i < 6 && x != null; i++) {
            if (x.isClickable()) return x;
            x = x.getParent();
        }
        return null;
    }

    private AccessibilityNodeInfo findClickable(AccessibilityNodeInfo n, String[] keys, boolean exact, String[] excl) {
        if (n == null) return null;
        CharSequence t = n.getText(), d = n.getContentDescription();
        if (matches(t == null ? null : t.toString(), keys, exact, excl) || matches(d == null ? null : d.toString(), keys, exact, excl)) {
            AccessibilityNodeInfo c = clickableUp(n);
            if (c != null) return c;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findClickable(n.getChild(i), keys, exact, excl);
            if (r != null) return r;
        }
        return null;
    }
}
