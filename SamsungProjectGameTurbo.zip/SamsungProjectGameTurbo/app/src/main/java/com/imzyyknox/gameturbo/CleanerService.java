package com.imzyyknox.gameturbo;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayDeque;
import java.util.Locale;

/**
 * Otomatisasi lewat Accessibility: membuka Info Aplikasi, menekan "Clear cache" / "Force stop"
 * seperti yang dilakukan pengguna, lalu lanjut ke aplikasi berikutnya tanpa menunggu lama.
 * Tidak ada tirai/layar penutup; progres dilaporkan ke log di floating window.
 */
public class CleanerService extends AccessibilityService {
    interface Listener { void on(String msg, boolean ok, boolean queueDone); }

    static final int CLEAR_CACHE = 1, FORCE_STOP = 2;
    static Listener listener;
    private static CleanerService inst;

    private static final String[] CLEAR = {"clear cache", "hapus cache", "bersihkan cache", "kosongkan cache", "hapus tembolok"};
    private static final String[] STORAGE = {"storage", "penyimpanan"};
    private static final String[] STORAGE_EXCL = {"clear", "hapus", "manage", "kelola", "data", "kosongkan", "bersihkan"};
    private static final String[] FORCE = {"force stop", "paksa berhenti", "paksa hentikan", "hentikan paksa", "force-stop"};
    private static final String[] CONFIRM_OK = {"ok", "oke", "yes", "ya"};

    private static final long POLL_MS = 110, TIMEOUT_MS = 5500;

    private static class Task {
        final String pkg, label; final int type;
        Task(String p, String l, int t) { pkg = p; label = l; type = t; }
    }

    private final ArrayDeque<Task> queue = new ArrayDeque<>();
    private final Handler h = new Handler(Looper.getMainLooper());
    private Task cur;
    private boolean busy;
    private int phase, depth, totalCount, doneCount, epoch;
    private long startedAt, phaseAt;

    static boolean enabled() { return inst != null; }
    static int pending() { return inst == null ? 0 : inst.queue.size() + (inst.cur != null ? 1 : 0); }
    static int total() { return inst == null ? 0 : inst.totalCount; }
    static int done() { return inst == null ? 0 : inst.doneCount; }
    static void cancel() { if (inst != null) inst.cancelAll(); }
    static void enqueue(String pkg, int type, String label) {
        if (inst == null) return;
        if (!inst.busy && inst.cur == null) { inst.totalCount = 0; inst.doneCount = 0; }
        inst.totalCount++;
        inst.queue.add(new Task(pkg, label == null ? pkg : label, type));
        if (!inst.busy) inst.next();
    }

    @Override protected void onServiceConnected() { super.onServiceConnected(); inst = this; }
    @Override public boolean onUnbind(Intent intent) { inst = null; return super.onUnbind(intent); }
    @Override public void onDestroy() { inst = null; h.removeCallbacksAndMessages(null); super.onDestroy(); }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }

    private void say(String m, boolean ok, boolean done) { if (listener != null) listener.on(m, ok, done); }

    private void next() {
        epoch++;
        cur = queue.poll();
        if (cur == null) { busy = false; return; }
        busy = true; phase = 0; depth = 1; startedAt = SystemClock.elapsedRealtime(); phaseAt = startedAt;
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + cur.pkg));
            // CLEAR_TASK: tiap aplikasi mulai dari halaman bersih, jadi tidak perlu tekan BACK di antara aplikasi.
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
            startActivity(i);
        } catch (Exception e) { finish("Gagal membuka Info Aplikasi: " + cur.label, false); return; }
        h.removeCallbacks(poll);
        h.postDelayed(poll, 160);
    }

    private final Runnable poll = new Runnable() {
        @Override public void run() {
            if (cur == null) return;
            if (SystemClock.elapsedRealtime() - startedAt > TIMEOUT_MS) { finish("Dilewati (tombol tidak ditemukan): " + cur.label, false); return; }
            try { step(); } catch (Exception e) { finish("Gagal: " + cur.label, false); return; }
            if (cur != null) h.postDelayed(this, POLL_MS);
        }
    };

    private void step() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        CharSequence pk = root.getPackageName();
        boolean inSettings = pk != null && pk.toString().toLowerCase(Locale.ROOT).contains("settings");
        boolean confirmPhase = cur.type == FORCE_STOP && phase == 1;
        if (!inSettings && !confirmPhase) return;
        if (cur.type == FORCE_STOP) stepForceStop(root); else stepClear(root);
    }

    private void stepForceStop(AccessibilityNodeInfo root) {
        if (phase == 0) {
            AccessibilityNodeInfo n = findClickable(root, FORCE, false, null);
            if (n == null) return;
            if (!n.isEnabled()) { finish("Sudah tidak berjalan: " + cur.label, true); return; }
            n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            phase = 1; phaseAt = SystemClock.elapsedRealtime();
            return;
        }
        if (SystemClock.elapsedRealtime() - phaseAt < 180) return;
        AccessibilityNodeInfo ok = findClickable(root, CONFIRM_OK, true, null);
        if (ok == null) ok = findClickable(root, FORCE, false, null);
        if (ok == null) return;
        ok.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        finish("Force stop: " + cur.label, true);
    }

    private void stepClear(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo n = findClickable(root, CLEAR, false, null);
        if (n != null) {
            if (!n.isEnabled()) { finish("Tidak ada cache: " + cur.label, true); return; }
            n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            finish("Cache dibersihkan: " + cur.label, true);
            return;
        }
        if (phase == 0) {
            AccessibilityNodeInfo s = findClickable(root, STORAGE, false, STORAGE_EXCL);
            if (s != null) {
                s.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                phase = 1; depth = 2; phaseAt = SystemClock.elapsedRealtime();
            } else scrollAny(root);
        } else scrollAny(root);
    }

    private void scrollAny(AccessibilityNodeInfo n) {
        if (n == null) return;
        if (n.isScrollable() && n.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) return;
        for (int i = 0; i < n.getChildCount(); i++) scrollAny(n.getChild(i));
    }

    private void finish(String msg, boolean ok) {
        final int backs = cur != null && cur.type == CLEAR_CACHE ? depth : 1;
        final boolean stop = cur != null && cur.type == FORCE_STOP;
        cur = null;
        doneCount++;
        h.removeCallbacks(poll);
        final boolean last = queue.isEmpty();
        say(msg, ok, last);
        if (!last) { h.postDelayed(this::next, stop ? 260 : 90); return; }
        busy = false;
        final int my = epoch;
        // Antrian habis: keluar dari Pengaturan, kembali ke layar sebelumnya.
        for (int k = 1; k <= backs; k++) h.postDelayed(() -> { if (my == epoch && cur == null) performGlobalAction(GLOBAL_ACTION_BACK); }, (stop ? 300L : 150L) * k);
    }

    private void cancelAll() {
        final int backs = depth;
        queue.clear(); cur = null; busy = false; epoch++;
        h.removeCallbacksAndMessages(null);
        for (int k = 1; k <= backs; k++) h.postDelayed(() -> performGlobalAction(GLOBAL_ACTION_BACK), 150L * k);
        say("Pembersihan dibatalkan", false, true);
    }

    private static boolean matches(String raw, String[] keys, boolean exact, String[] excl) {
        if (raw == null) return false;
        String s = raw.toLowerCase(Locale.ROOT).trim();
        if (s.isEmpty() || s.length() > 60) return false;
        if (excl != null) for (String x : excl) if (s.contains(x)) return false;
        for (String k : keys) { if (exact ? s.equals(k) : s.contains(k)) return true; }
        return false;
    }

    private AccessibilityNodeInfo clickableUp(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo x = n;
        for (int i = 0; i < 6 && x != null; i++) {
            if (x.isClickable()) return x;
            x = x.getParent();
        }
        return null;
    }

    private AccessibilityNodeInfo findClickable(AccessibilityNodeInfo n, String[] keys, boolean exact, String[] excl) {
        if (n == null) return null;
        CharSequence t = n.getText(), d = n.getContentDescription();
        if (matches(t == null ? null : t.toString(), keys, exact, excl) || matches(d == null ? null : d.toString(), keys, exact, excl)) {
            AccessibilityNodeInfo c = clickableUp(n);
            if (c != null) return c;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findClickable(n.getChild(i), keys, exact, excl);
            if (r != null) return r;
        }
        return null;
    }
}
